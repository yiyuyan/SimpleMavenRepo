package committee.nova.mods.lighteco.event;

import committee.nova.mods.lighteco.api.interfaces.ICurrency;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.math.BigDecimal;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;

/**
 * BalanceVaryEvent
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/5/9 上午12:57
 */
public class BalanceVaryEvent {
    public static final Event<Pre> PRE = EventFactory.createArrayBacked(Pre.class, callbacks ->
            (player, baseValue, currency,
             argChecker, processor, resultChecker
            ) -> {
        for (Pre callback : callbacks) {
            if (!callback.pre(player, baseValue, currency, argChecker, processor, resultChecker)) {
                return false;
            }
        }
        return true;
    });

    public static final Event<Post> POST = EventFactory.createArrayBacked(Post.class, callbacks ->
            (player, baseValue, currency,
             oldValue, newValue
            ) -> {
                for (Post callback : callbacks) {
                    callback.post(player, baseValue, currency,
                            oldValue, newValue);
                }
            });

    @FunctionalInterface
    public interface Pre {
        boolean pre(class_1657 player, BigDecimal baseValue, ICurrency currency,
                    BiPredicate<class_1657, BigDecimal> argChecker,
                    BiFunction<class_1657, BigDecimal, BigDecimal> processor,
                    BiPredicate<class_1657, BigDecimal> resultChecker
        );
    }

    @FunctionalInterface
    public interface Post {
        void post(class_1657 player, BigDecimal baseValue, ICurrency currency,
                 BigDecimal oldValue, BigDecimal newValue);
    }
}
