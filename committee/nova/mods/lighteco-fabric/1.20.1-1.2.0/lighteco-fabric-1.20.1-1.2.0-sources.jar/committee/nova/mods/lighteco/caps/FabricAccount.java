package committee.nova.mods.lighteco.caps;

import committee.nova.mods.lighteco.api.interfaces.IAccount;
import committee.nova.mods.lighteco.impl.DefaultAccount;
import dev.onyxstudios.cca.api.v3.entity.PlayerComponent;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * FabricAccount
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/5/9 上午12:43
 */
public class FabricAccount extends DefaultAccount implements PlayerComponent<FabricAccount> {
    private static final String TAG_ACCOUNT = "accounts";

    public FabricAccount(class_1657 player) {}

    @Override
    public void readFromNbt(@NotNull class_2487 tag) {
        final class_2499 accounts = tag.method_10554(TAG_ACCOUNT, class_2520.field_33260);
        for(int i = 0; i < accounts.size(); ++i) {
            class_2487 account = accounts.method_10602(i);
            this.account.put(account.method_10558("currency"), new BigDecimal(account.method_10558("balance")));
        }
    }

    @Override
    public void writeToNbt(@NotNull class_2487 tag) {
        final class_2499 accounts = new class_2499();

        this.account.forEach((currency, bigDecimal) -> {
            final class_2487 account = new class_2487();
            account.method_10582("currency", currency);
            account.method_10582("balance", bigDecimal.toPlainString());
            accounts.add(account);
        });

        tag.method_10566(TAG_ACCOUNT, accounts);
    }
}
