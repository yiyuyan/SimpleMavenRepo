package committee.nova.mods.lighteco.api.interfaces;

import committee.nova.mods.lighteco.api.util.EcoUtils;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import net.minecraft.class_1657;

import static committee.nova.mods.lighteco.api.util.EcoUtils.NON_NEGATIVE;

/**
 * EcoApi
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/5/8 下午10:31
 */
public interface IEco {
    Optional<BigDecimal> getBalance(class_1657 player, ICurrency currency);

    EcoUtils.EcoActionResult vary(
            class_1657 player, BigDecimal value, ICurrency currency,
            BiPredicate<class_1657, BigDecimal> argChecker,
            BiFunction<class_1657, BigDecimal, BigDecimal> processor,
            BiPredicate<class_1657, BigDecimal> resultChecker
    );

    default EcoUtils.EcoActionResult debt(class_1657 player, BigDecimal value, ICurrency currency){
        return vary(player, value, currency, NON_NEGATIVE, (p, v) -> v, NON_NEGATIVE);
    };

    default EcoUtils.EcoActionResult credit(class_1657 player, BigDecimal value, ICurrency currency){
        return vary(player, value, currency, NON_NEGATIVE, (p, v) -> v.negate(), NON_NEGATIVE);
    }
}
