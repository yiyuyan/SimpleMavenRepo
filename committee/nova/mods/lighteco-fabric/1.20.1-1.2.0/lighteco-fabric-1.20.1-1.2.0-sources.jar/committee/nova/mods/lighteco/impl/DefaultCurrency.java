package committee.nova.mods.lighteco.impl;

import committee.nova.mods.lighteco.api.interfaces.ICurrency;
import net.minecraft.class_2561;

/**
 * DefaultCurrency
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/5/8 下午10:32
 */
public class DefaultCurrency implements ICurrency {
    public static final DefaultCurrency INSTANCE = new DefaultCurrency();
    @Override
    public class_2561 getDescription() {
        return class_2561.method_43471("info.lighteco.coin_currency");
    }

    @Override
    public String getCurrencyName() {
        return "coin";
    }
}
