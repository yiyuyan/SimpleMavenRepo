package committee.nova.mods.lighteco.test;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

/**
 * TestEvent
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/6/25 下午8:39
 */
public class TestEvent {
    public static void init(){
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof class_1657 player){
                ApiHandler.addBalance(player, 1000);
                player.method_43496(class_2561.method_43470(String.valueOf(ApiHandler.getBalance(player))));
            }
        });
    }
}
