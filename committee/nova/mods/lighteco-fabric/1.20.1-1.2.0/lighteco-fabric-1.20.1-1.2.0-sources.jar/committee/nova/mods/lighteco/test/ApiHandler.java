package committee.nova.mods.lighteco.test;

import committee.nova.mods.lighteco.api.FabricEco;
import committee.nova.mods.lighteco.api.util.EcoUtils;
import java.math.BigDecimal;
import java.util.Optional;
import net.minecraft.class_1657;

/**
 * committee.nova.mods.lighteco.test.ApiHandler
 *
 * @author cnlimiter
 * @version 1.0
 * @description
 * @date 2024/6/25 下午8:32
 */
public class ApiHandler {
    public static double getBalance(class_1657 player) {
        Optional<BigDecimal> balance = FabricEco.INSTANCE.getBalance(player);
        double checkBalance = balance.map(BigDecimal::doubleValue).orElse(0.0);
        return safetyCheck(checkBalance);
    }

    public static EcoUtils.EcoActionResult addBalance(class_1657 player, double value) {
        // First round the value to 2 decimal places
        double afterValue = roundDouble(value);
        // Get the current balance
        double currentBalance = getBalance(player);
        // Add the value to the current balance
        double newBalance = safetyCheck(currentBalance + afterValue);
        // Calculate the final value
        BigDecimal finalValue = BigDecimal.valueOf(newBalance - currentBalance);
        return FabricEco.INSTANCE.debt(player, finalValue);
    }

    public static EcoUtils.EcoActionResult removeBalance(class_1657 player, double value) {
        double afterValue = roundDouble(value);
        double currentBalance = getBalance(player);
        double newBalance = safetyCheck(currentBalance - afterValue);
        BigDecimal finalValue = BigDecimal.valueOf(currentBalance - newBalance);
        return FabricEco.INSTANCE.credit(player, finalValue);
    }

    public static EcoUtils.EcoActionResult setBalance(class_1657 player, double value) {
        double afterValue = roundDouble(value);
        double currentBalance = getBalance(player);
        double newBalance = safetyCheck(afterValue);
        BigDecimal finalValue = BigDecimal.valueOf(newBalance - currentBalance);
        return FabricEco.INSTANCE.debt(player, finalValue);
    }

    public static double safetyCheck(double money) {
        double minBalance = 0;
        double maxBalance = Double.MAX_VALUE;
        return Math.max(minBalance, Math.min(maxBalance, money));
    }
    public static double roundDouble(double value) {
        return Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2);
    }
}
