/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2021-2023 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.lang.invoke.MethodHandles;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.ProtectionDomain;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import org.gradle.api.logging.Logger;
import org.gradle.api.logging.Logging;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import com.sun.tools.attach.VirtualMachine;

/**
 * Dynamically generates a temporary Java agent, attaches it to the running JVM,
 * and patches TinyRemapper's handleConflicts method to truly skip all conflict
 * exceptions when ignoreConflicts=true.
 */
public final class TinyRemapperPatcher {
	private static final Logger LOGGER = Logging.getLogger(TinyRemapperPatcher.class);
	private static final String TINY_REMAPPER_CLASS = "net/fabricmc/tinyremapper/TinyRemapper";
	private static final String TINY_REMAPPER_CLASS_DOTS = "net.fabricmc.tinyremapper.TinyRemapper";
	private static volatile boolean patched = false;
	private static final Object lock = new Object();

	private TinyRemapperPatcher() {
	}

	/**
	 * Ensures TinyRemapper's handleConflicts is patched to honor ignoreConflicts=true
	 * for ALL conflict types including targetNameCheckFailed. Must be called before
	 * the TinyRemapper class is first referenced.
	 */
	public static void ensurePatched() {
		if (patched) {
			return;
		}

		synchronized (lock) {
			if (patched) {
				return;
			}

			try {
				patchJarOnDisk();

				Instrumentation inst = getOrCreateInstrumentation();
				if (inst == null) {
					LOGGER.warn("TinyRemapperPatcher: Failed to obtain Instrumentation, conflict patching disabled");
					return;
				}

				LOGGER.lifecycle("TinyRemapperPatcher: Instrumentation obtained, {} classes already loaded", inst.getAllLoadedClasses().length);

				TinyRemapperTransformer transformer = new TinyRemapperTransformer();
				inst.addTransformer(transformer, true);
				LOGGER.info("TinyRemapperPatcher: Registered transformer for TinyRemapper conflict patching");

				// Try to find TinyRemapper in already-loaded classes and retransform it
				boolean found = false;
				Class<?> tmClass = null;
				for (Class<?> loaded : inst.getAllLoadedClasses()) {
					LOGGER.lifecycle("TinyRemapperPatcher: loaded class: {}", loaded.getName());
					if (TINY_REMAPPER_CLASS_DOTS.equals(loaded.getName())) {
						tmClass = loaded;
						break;
					}
				}

				if (tmClass != null) {
					LOGGER.lifecycle("TinyRemapperPatcher: Found already-loaded TinyRemapper: classloader={}, module={}",
							tmClass.getClassLoader(), tmClass.getModule());
					// Try retransformClasses first
					if (inst.isModifiableClass(tmClass)) {
						try {
							inst.retransformClasses(tmClass);
							LOGGER.lifecycle("TinyRemapperPatcher: retransformClasses succeeded");
							found = true;
						} catch (UnmodifiableClassException e) {
							LOGGER.warn("TinyRemapperPatcher: retransformClasses failed: {}", e.getMessage());
						} catch (Throwable t) {
							LOGGER.warn("TinyRemapperPatcher: retransformClasses error: {}", t.getMessage(), t);
						}
					} else {
						LOGGER.warn("TinyRemapperPatcher: isModifiableClass=false for TinyRemapper");
					}

					// If retransform didn't work, try redefineClasses directly
					if (!found && transformer.patchedClass) {
						LOGGER.lifecycle("TinyRemapperPatcher: Transformer produced patched bytes, trying redefineClasses...");
						try {
							Path patchedPath = Path.of(System.getProperty("java.io.tmpdir"),
									"fabricloom-agent", "TinyRemapper-patched.class");
							if (Files.exists(patchedPath)) {
								byte[] patchedBytes = Files.readAllBytes(patchedPath);
								ClassDefinition def = new ClassDefinition(tmClass, patchedBytes);
								inst.redefineClasses(def);
								LOGGER.lifecycle("TinyRemapperPatcher: redefineClasses succeeded!");
								found = true;
							}
						} catch (Exception e) {
							LOGGER.warn("TinyRemapperPatcher: redefineClasses failed: {}", e.getMessage(), e);
						}
					}

					if (!found) {
						LOGGER.warn("TinyRemapperPatcher: All retransform/redefine attempts failed for already-loaded TinyRemapper");
					}
				} else {
					LOGGER.lifecycle("TinyRemapperPatcher: TinyRemapper not yet loaded, transformer will fire on first use");
				}

				patched = true;
			} catch (Exception e) {
				LOGGER.warn("TinyRemapperPatcher: Failed to patch TinyRemapper: {}", e.getMessage(), e);
			}
		}
	}

	private static Instrumentation getOrCreateInstrumentation() throws Exception {
		Instrumentation inst = (Instrumentation) System.getProperties().get("_fabricloom_inst_");

		if (inst != null) {
			return inst;
		}

		Path agentJar = generateAgentJar();

		try {
			loadAgent(agentJar);
			inst = (Instrumentation) System.getProperties().get("_fabricloom_inst_");
			return inst;
		} finally {
			try {
				Files.deleteIfExists(agentJar);
			} catch (IOException ignored) {
			}
		}
	}

	private static Path generateAgentJar() throws IOException {
		Path tmpDir = Path.of(System.getProperty("java.io.tmpdir"), "fabricloom-agent");
		Files.createDirectories(tmpDir);
		Path jarPath = tmpDir.resolve("fabricloom-tinyremapper-patcher.jar");

		String agentClassName = "net/fabricmc/loom/util/FabricLoomAgent";
		byte[] agentBytes = generateAgentClass(agentClassName);

		Manifest manifest = new Manifest();
		Attributes attrs = manifest.getMainAttributes();
		attrs.put(Attributes.Name.MANIFEST_VERSION, "1.0");
		attrs.put(new Attributes.Name("Premain-Class"), agentClassName.replace('/', '.'));
		attrs.put(new Attributes.Name("Agent-Class"), agentClassName.replace('/', '.'));
		attrs.put(new Attributes.Name("Can-Retransform-Classes"), "true");
		attrs.put(new Attributes.Name("Can-Redefine-Classes"), "true");

		try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(jarPath.toFile()))) {
			JarEntry manifestEntry = new JarEntry(JarFile.MANIFEST_NAME);
			jos.putNextEntry(manifestEntry);
			manifest.write(jos);
			jos.closeEntry();

			JarEntry classEntry = new JarEntry(agentClassName + ".class");
			jos.putNextEntry(classEntry);
			jos.write(agentBytes);
			jos.closeEntry();
		}

		return jarPath;
	}

	private static byte[] generateAgentClass(String internalName) {
		ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
		cw.visit(Opcodes.V11, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, internalName, null, "java/lang/Object", null);

		MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
		mv.visitCode();
		mv.visitVarInsn(Opcodes.ALOAD, 0);
		mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
		mv.visitInsn(Opcodes.RETURN);
		mv.visitMaxs(1, 1);
		mv.visitEnd();

		String desc = "(Ljava/lang/String;Ljava/lang/instrument/Instrumentation;)V";

		mv = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "premain", desc, null, null);
		mv.visitCode();
		mv.visitVarInsn(Opcodes.ALOAD, 0);
		mv.visitVarInsn(Opcodes.ALOAD, 1);
		mv.visitMethodInsn(Opcodes.INVOKESTATIC, internalName, "init", desc, false);
		mv.visitInsn(Opcodes.RETURN);
		mv.visitMaxs(2, 2);
		mv.visitEnd();

		mv = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "agentmain", desc, null, null);
		mv.visitCode();
		mv.visitVarInsn(Opcodes.ALOAD, 0);
		mv.visitVarInsn(Opcodes.ALOAD, 1);
		mv.visitMethodInsn(Opcodes.INVOKESTATIC, internalName, "init", desc, false);
		mv.visitInsn(Opcodes.RETURN);
		mv.visitMaxs(2, 2);
		mv.visitEnd();

		mv = cw.visitMethod(Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC, "init", desc, null, null);
		mv.visitCode();
		mv.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/System", "getProperties", "()Ljava/util/Properties;", false);
		mv.visitLdcInsn("_fabricloom_inst_");
		mv.visitVarInsn(Opcodes.ALOAD, 1);
		mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/util/Properties", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", false);
		mv.visitInsn(Opcodes.POP);
		mv.visitInsn(Opcodes.RETURN);
		mv.visitMaxs(3, 2);
		mv.visitEnd();

		cw.visitEnd();
		return cw.toByteArray();
	}

	private static void loadAgent(Path agentJar) throws Exception {
		openAttachModule();
		enableSelfAttach();

		String pid = ManagementFactory.getRuntimeMXBean().getName().split("@")[0];
		VirtualMachine vm = VirtualMachine.attach(pid);
		try {
			vm.loadAgent(agentJar.toAbsolutePath().toString());
		} finally {
			vm.detach();
		}
	}

	private static void enableSelfAttach() {
		System.setProperty("jdk.attach.allowAttachSelf", "true");

		try {
			Class<?> vmClass = Class.forName("sun.tools.attach.HotSpotVirtualMachine");
			Field allowAttachSelfField = vmClass.getDeclaredField("ALLOW_ATTACH_SELF");
			sun.misc.Unsafe unsafe = getUnsafe();
			Object base = unsafe.staticFieldBase(allowAttachSelfField);
			long offset = unsafe.staticFieldOffset(allowAttachSelfField);
			unsafe.putBoolean(base, offset, true);
		} catch (NoSuchFieldException | ClassNotFoundException ignored) {
		}
	}

	private static sun.misc.Unsafe getUnsafe() {
		try {
			Field theUnsafe = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
			theUnsafe.setAccessible(true);
			return (sun.misc.Unsafe) theUnsafe.get(null);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static void patchJarOnDisk() {
		try {
			// Try to locate tiny-remapper jar via classpath resource
			var resource = TinyRemapperPatcher.class.getClassLoader().getResource(TINY_REMAPPER_CLASS + ".class");

			if (resource != null && "jar".equals(resource.getProtocol())) {
				String path = resource.getPath();
				int bang = path.indexOf('!');

				if (bang > 0) {
					String jarPathStr = java.net.URLDecoder.decode(path.substring(5, bang), java.nio.charset.StandardCharsets.UTF_8);

					if (jarPathStr.length() >= 3 && jarPathStr.charAt(0) == '/' && jarPathStr.charAt(2) == ':') {
						jarPathStr = jarPathStr.substring(1);
					}

					Path jarPath = Path.of(jarPathStr);
					patchSingleJar(jarPath);
				}
			}

			// Also scan Gradle cache for all tiny-remapper jars (covers worker classpaths)
			String gradleUserHome = System.getProperty("gradle.user.home", System.getProperty("user.home") + "/.gradle");
			Path cacheBase = Path.of(gradleUserHome, "caches", "modules-2", "files-2.1", "net.fabricmc", "tiny-remapper");

			if (Files.exists(cacheBase)) {
				try (var walk = Files.walk(cacheBase)) {
					walk.filter(p -> p.getFileName().toString().endsWith(".jar"))
							.forEach(p -> {
								try {
									patchSingleJar(p);
								} catch (Exception e) {
									LOGGER.lifecycle("TinyRemapperPatcher: Failed to patch jar {}: {}", p, e.getMessage());
								}
							});
				}
			}
		} catch (Exception e) {
			LOGGER.lifecycle("TinyRemapperPatcher: patchJarOnDisk failed: {}", e.getMessage(), e);
		}
	}

	private static void patchSingleJar(Path jarPath) throws IOException {
		if (!Files.exists(jarPath) || Files.isDirectory(jarPath)) {
			return;
		}

		// Check if already patched by looking for marker
		try (var jf = new JarFile(jarPath.toFile())) {
			var entry = jf.getJarEntry(TINY_REMAPPER_CLASS + ".class");

			if (entry == null) {
				return;
			}

			try (var is = jf.getInputStream(entry)) {
				byte[] bytes = is.readAllBytes();

				// Already patched check: patched class is larger than original (46186 vs 46145)
				if (bytes.length > 46160) {
					return;
				}

				ClassReader cr = new ClassReader(bytes);
				ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS) {
					@Override
					protected String getCommonSuperClass(String type1, String type2) {
						try {
							return super.getCommonSuperClass(type1, type2);
						} catch (TypeNotPresentException e) {
							return "java/lang/Object";
						}
					}
				};
				boolean[] patched = new boolean[1];

				ClassVisitor cv = new ClassVisitor(Opcodes.ASM9, cw) {
					@Override
					public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
						MethodVisitor mv = super.visitMethod(access, name, descriptor, signature, exceptions);

						if ("handleConflicts".equals(name) && descriptor.startsWith("(L") && descriptor.endsWith(")V")) {
							patched[0] = true;
							return new HandleConflictsPatcher(mv);
						}

						return mv;
					}
				};

				cr.accept(cv, 0);

				if (!patched[0]) {
					return;
				}

				byte[] newBytes = cw.toByteArray();

				// Check if already patched (bytes identical after patching would be same, but we can detect by checking if patch already applied)
				// Simple check: if patched bytes equal original, already patched
				if (java.util.Arrays.equals(bytes, newBytes)) {
					return;
				}

				// Write patched jar to temp file and atomically replace
				Path tmp = Files.createTempFile(jarPath.getParent(), "tiny-remapper-patch-", ".jar");

				try (var in = new JarFile(jarPath.toFile()); var out = new JarOutputStream(Files.newOutputStream(tmp))) {
					var entries = in.entries();

					while (entries.hasMoreElements()) {
						var e = entries.nextElement();
						byte[] data;

						if (e.getName().equals(TINY_REMAPPER_CLASS + ".class")) {
							data = newBytes;
						} else {
							try (var eis = in.getInputStream(e)) {
								data = eis.readAllBytes();
							}
						}

						JarEntry ne = new JarEntry(e.getName());
						ne.setTime(e.getTime());
						ne.setComment(e.getComment());
						if (e.getExtra() != null) {
							ne.setExtra(e.getExtra());
						}

						out.putNextEntry(ne);
						out.write(data);
						out.closeEntry();
					}
				}

				try {
					Files.move(tmp, jarPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
				} catch (java.nio.file.AtomicMoveNotSupportedException e) {
					Files.move(tmp, jarPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
				}

				LOGGER.lifecycle("TinyRemapperPatcher: Patched jar on disk: {}", jarPath);
			}
		}
	}

	private static final MethodHandles.Lookup IMPL_LOOKUP;

	static {
		MethodHandles.Lookup lookup = null;
		try {
			Field lookupField = MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP");
			sun.misc.Unsafe unsafe = getUnsafe();
			Object base = unsafe.staticFieldBase(lookupField);
			long offset = unsafe.staticFieldOffset(lookupField);
			lookup = (MethodHandles.Lookup) unsafe.getObject(base, offset);
		} catch (Exception e) {
			// Fallback
		}
		IMPL_LOOKUP = lookup;
	}

	private static void openAttachModule() {
		try {
			Module currentModule = TinyRemapperPatcher.class.getModule();
			ModuleLayer bootLayer = ModuleLayer.boot();
			var attachModuleOpt = bootLayer.findModule("jdk.attach");

			if (attachModuleOpt.isEmpty()) {
				LOGGER.warn("TinyRemapperPatcher: jdk.attach module not found");
				return;
			}

			Module attachModule = attachModuleOpt.get();

			try {
				var implAddOpens = IMPL_LOOKUP.findVirtual(
						Module.class, "implAddOpens",
						java.lang.invoke.MethodType.methodType(Void.TYPE, String.class, Module.class));
				implAddOpens.invoke(attachModule, "sun.tools.attach", currentModule);
			} catch (Throwable t1) {
				try {
					sun.misc.Unsafe unsafe = getUnsafe();
					Field openPackagesField = Module.class.getDeclaredField("openPackages");
					long offset = unsafe.objectFieldOffset(openPackagesField);
					@SuppressWarnings("unchecked")
					java.util.Map<String, java.util.Set<Module>> openPackages =
							(java.util.Map<String, java.util.Set<Module>>) unsafe.getObject(attachModule, offset);
					if (openPackages == null) {
						openPackages = new java.util.HashMap<>();
						unsafe.putObject(attachModule, offset, openPackages);
					}
					openPackages.computeIfAbsent("sun.tools.attach", k -> new java.util.HashSet<>()).add(currentModule);
				} catch (Throwable t2) {
					LOGGER.warn("TinyRemapperPatcher: Failed to open jdk.attach module: {}", t2.getMessage());
				}
			}
		} catch (Exception e) {
			LOGGER.warn("TinyRemapperPatcher: Failed to open attach module: {}", e.getMessage());
		}
	}

/**
 * ASM ClassFileTransformer that patches TinyRemapper.handleConflicts() to make
 * the final throw conditional on ignoreConflicts. The conflict resolution logic
 * still runs (fixing fixable conflicts), but the exception is suppressed when
 * ignoreConflicts=true, preventing duplicate methods in the output jar.
 */
private static class TinyRemapperTransformer implements ClassFileTransformer {
		private volatile boolean patchedClass = false;

		@Override
		public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
				ProtectionDomain protectionDomain, byte[] classfileBuffer) {
			/*LOGGER.lifecycle("TinyRemapperPatcher: transform() called for {} (loader={}, redefined={}, size={})",
					className, loader, classBeingRedefined != null, classfileBuffer != null ? classfileBuffer.length : 0);
*/
			if (!TINY_REMAPPER_CLASS.equals(className)) {
				return null;
			}

			LOGGER.lifecycle("TinyRemapperPatcher: Matched TinyRemapper class! Attempting patch...");

			try {
				Path dumpDir = Path.of(System.getProperty("java.io.tmpdir"), "fabricloom-agent");
				Files.createDirectories(dumpDir);
				Path origDump = dumpDir.resolve("TinyRemapper-original.class");
				Files.write(origDump, classfileBuffer);
				LOGGER.lifecycle("TinyRemapperPatcher: Dumped original class to {}", origDump);

				ClassReader cr = new ClassReader(classfileBuffer);
				ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS) {
					@Override
					protected String getCommonSuperClass(String type1, String type2) {
						try {
							return super.getCommonSuperClass(type1, type2);
						} catch (TypeNotPresentException e) {
							return "java/lang/Object";
						}
					}
				};

				ClassVisitor cv = new ClassVisitor(Opcodes.ASM9, cw) {
					@Override
					public MethodVisitor visitMethod(int access, String name, String descriptor,
							String signature, String[] exceptions) {
						MethodVisitor mv = super.visitMethod(access, name, descriptor, signature, exceptions);

						if ("handleConflicts".equals(name)
								&& descriptor.startsWith("(L")
								&& descriptor.endsWith(")V")) {
							LOGGER.lifecycle("TinyRemapperPatcher: Found handleConflicts method: {}{}", name, descriptor);
							return new HandleConflictsPatcher(mv);
						}

						return mv;
					}
				};

				cr.accept(cv, 0);
				byte[] result = cw.toByteArray();

				Path patchedDump = dumpDir.resolve("TinyRemapper-patched.class");
				Files.write(patchedDump, result);
				LOGGER.lifecycle("TinyRemapperPatcher: Dumped patched class to {}", patchedDump);
				LOGGER.lifecycle("TinyRemapperPatcher: Successfully patched TinyRemapper ({} -> {} bytes)",
						classfileBuffer.length, result.length);

				patchedClass = true;
				return result;
			} catch (Exception e) {
				LOGGER.warn("TinyRemapperPatcher: Failed to transform TinyRemapper: {}", e.getMessage(), e);
				return null;
			}
		}
	}

	/**
	 * Patches handleConflicts() so the final throw is skipped when ignoreConflicts=true.
	 * The conflict resolution logic (fixable conflicts) still runs normally.
	 * Only the ATHROW for "Unfixable conflicts" is made conditional.
	 */
	private static class HandleConflictsPatcher extends MethodVisitor {
		private boolean patchedThrow = false;

		HandleConflictsPatcher(MethodVisitor delegate) {
			super(Opcodes.ASM9, delegate);
		}

			@Override
		public void visitInsn(int opcode) {
			if (opcode == Opcodes.ATHROW && !patchedThrow) {
				patchedThrow = true;
				Label skipThrow = new Label();

				// Always log when we patch the throw
				visitVarInsn(Opcodes.ALOAD, 0);
				visitFieldInsn(Opcodes.GETFIELD, TINY_REMAPPER_CLASS, "ignoreConflicts", "Z");
				visitJumpInsn(Opcodes.IFEQ, skipThrow);
				// When ignoreConflicts=true, log and return instead of throwing
				visitLdcInsn("TinyRemapperPatcher: suppressing Unfixable conflicts due to ignoreConflicts=true");
				visitVarInsn(Opcodes.ALOAD, 0);
				visitMethodInsn(Opcodes.INVOKEVIRTUAL, "net/fabricmc/tinyremapper/TinyRemapper", "getLogger", "()Lnet/fabricmc/tinyremapper/api/TrLogger;", false);
				visitInsn(Opcodes.SWAP);
				visitMethodInsn(Opcodes.INVOKEINTERFACE, "net/fabricmc/tinyremapper/api/TrLogger", "warn", "(Ljava/lang/String;)V", true);
				visitInsn(Opcodes.RETURN);
				visitLabel(skipThrow);
			}
			super.visitInsn(opcode);
		}
	}
}
