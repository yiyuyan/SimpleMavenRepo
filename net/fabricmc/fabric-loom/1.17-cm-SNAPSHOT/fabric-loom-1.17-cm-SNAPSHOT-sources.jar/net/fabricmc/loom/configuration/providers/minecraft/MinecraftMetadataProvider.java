/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2023 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.configuration.providers.minecraft;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import org.gradle.api.Project;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.artifacts.FileCollectionDependency;
import org.gradle.api.provider.Property;
import org.jspecify.annotations.Nullable;

import net.fabricmc.loom.LoomGradleExtension;
import net.fabricmc.loom.LoomGradlePlugin;
import net.fabricmc.loom.configuration.ConfigContext;
import net.fabricmc.loom.configuration.DependencyInfo;
import net.fabricmc.loom.configuration.providers.minecraft.ManifestLocations.ManifestLocation;
import net.fabricmc.loom.util.Constants;
import net.fabricmc.loom.util.download.DownloadBuilder;

public final class MinecraftMetadataProvider {
	private final Options options;
	private final Function<String, DownloadBuilder> download;

	private ManifestEntryLocation versionEntry;
	private MinecraftVersionMeta versionMeta;

	private final boolean fileDependency;
	@Nullable
	private final File localMinecraftJar;
	@Nullable
	private final MinecraftVersionMeta syntheticVersionMeta;

	private MinecraftMetadataProvider(Options options, Function<String, DownloadBuilder> download,
			boolean fileDependency, @Nullable File localMinecraftJar, @Nullable MinecraftVersionMeta syntheticVersionMeta) {
		this.options = options;
		this.download = download;
		this.fileDependency = fileDependency;
		this.localMinecraftJar = localMinecraftJar;
		this.syntheticVersionMeta = syntheticVersionMeta;
	}

	public static MinecraftMetadataProvider create(ConfigContext configContext) {
		final DependencyInfo dependency = DependencyInfo.create(configContext.project(), Constants.Configurations.MINECRAFT);

		if (dependency instanceof net.fabricmc.loom.configuration.FileDependencyInfo fileDepInfo) {
			final Dependency rawDep = fileDepInfo.getRawDependency();
			if (rawDep instanceof FileCollectionDependency fileCollectionDependency) {
				final File localJar = fileCollectionDependency.getFiles().getFiles().stream().findFirst()
						.orElseThrow(() -> new IllegalStateException("File dependency for 'minecraft' has no files"));

				// Try to get the real minecraft version from project properties (e.g. gradle.properties)
				// so downstream plugins like ploceus can resolve version-specific artifacts.
				// Fall back to extracting from the jar filename.
				String syntheticVersion = configContext.project().findProperty("minecraft_version") instanceof String propVersion
						? propVersion
						: extractVersionFromFileName(localJar.getName());

				LOGGER.info("Using local minecraft jar: {} (synthetic version: {})", localJar.getAbsolutePath(), syntheticVersion);

				Options opts = MinecraftMetadataProvider.Options.create(syntheticVersion, configContext.project());
				MinecraftVersionMeta syntheticMeta = fetchVersionMetaForFileDependency(syntheticVersion, opts, configContext.extension()::download);

				if (syntheticMeta == null) {
					LOGGER.warn("Failed to fetch real version meta for {}, falling back to dummy", syntheticVersion);
					syntheticMeta = createSyntheticVersionMeta();
				} else {
					LOGGER.info("Fetched real version meta for {}: id={}, assets={}, libraries={}", syntheticVersion, syntheticMeta.id(), syntheticMeta.assets(), syntheticMeta.libraries().size());
				}

				return new MinecraftMetadataProvider(
						opts,
						configContext.extension()::download,
						true,
						localJar,
						syntheticMeta
				);
			}
		}

		final String minecraftVersion = dependency.getDependency().getVersion();

		return new MinecraftMetadataProvider(
				MinecraftMetadataProvider.Options.create(minecraftVersion, configContext.project()),
				configContext.extension()::download,
				false,
				null,
				null
		);
	}

	private static String extractVersionFromFileName(String fileName) {
		int lastDot = fileName.lastIndexOf('.');
		return lastDot > 0 ? fileName.substring(0, lastDot) : fileName;
	}

	@Nullable
	private static MinecraftVersionMeta fetchVersionMetaForFileDependency(String version, Options options, Function<String, DownloadBuilder> download) {
		try {
			// Try to find the version in the versions manifest and download its json
			List<ManifestEntrySupplier> suppliers = new ArrayList<>();

			for (ManifestLocations.ManifestLocation location : options.versionsManifests()) {
				suppliers.add(() -> getManifestEntryStatic(location, options, download, false));
			}

			for (ManifestLocations.ManifestLocation location : options.versionsManifests()) {
				suppliers.add(() -> getManifestEntryStatic(location, options, download, true));
			}

			ManifestEntryLocation versionEntry = null;

			for (ManifestEntrySupplier supplier : suppliers) {
				ManifestEntryLocation entry = supplier.get();

				if (entry != null) {
					versionEntry = entry;
					break;
				}
			}

			if (versionEntry == null) {
				LOGGER.warn("Could not find version {} in manifest for file dependency", version);
				return null;
			}

			return readVersionMetaStatic(versionEntry, options, download);
		} catch (Exception e) {
			LOGGER.warn("Failed to fetch version meta for {}: {}", version, e.getMessage());
			return null;
		}
	}

	private static ManifestEntryLocation getManifestEntryStatic(ManifestLocations.ManifestLocation location, Options options, Function<String, DownloadBuilder> download, boolean forceDownload) throws IOException {
		DownloadBuilder builder = download.apply(location.url());

		if (forceDownload) {
			builder = builder.forceDownload();
		} else {
			builder = builder.defaultCache();
		}

		final Path cacheFile = location.cacheFile(options.userCache());
		final String versionManifest = builder.downloadString(cacheFile);
		final VersionsManifest manifest = LoomGradlePlugin.GSON.fromJson(versionManifest, VersionsManifest.class);
		final VersionsManifest.Version ver = manifest.getVersion(options.minecraftVersion());

		if (ver != null) {
			return new ManifestEntryLocation(location, ver);
		}

		return null;
	}

	private static MinecraftVersionMeta readVersionMetaStatic(ManifestEntryLocation versionEntry, Options options, Function<String, DownloadBuilder> download) throws IOException {
		final DownloadBuilder builder = download.apply(versionEntry.entry.url());

		if (versionEntry.entry.sha1() != null) {
			builder.sha1(versionEntry.entry.sha1());
		} else {
			builder.defaultCache();
		}

		final String fileName;

		if (versionEntry.manifest == null) {
			fileName = "minecraft_info_" + Integer.toHexString(versionEntry.entry.url().hashCode()) + ".json";
		} else {
			fileName = versionEntry.manifest.name() + "_minecraft_info.json";
		}

		final Path cacheFile = options.workingDir().resolve(fileName);
		final String json = builder.downloadString(cacheFile);
		return LoomGradlePlugin.GSON.fromJson(json, MinecraftVersionMeta.class);
	}

	/**
	 * Creates a minimal synthetic MinecraftVersionMeta for file dependency mode.
	 * This allows downstream code that accesses version metadata to function without errors.
	 */
	private static MinecraftVersionMeta createSyntheticVersionMeta() {
		// Minimal download entry to satisfy callers that check for client/server downloads
		MinecraftVersionMeta.Download dummyDownload = new MinecraftVersionMeta.Download("", "", 0, "");
		Map<String, MinecraftVersionMeta.Download> downloads = Map.of(
				"client", dummyDownload,
				"server", dummyDownload
		);

		// Dummy asset index to avoid NPE in DownloadAssetsTask; task will skip download for file dependency
		MinecraftVersionMeta.AssetIndex dummyAssetIndex = new MinecraftVersionMeta.AssetIndex(
				"legacy", 0, "legacy.json", "da39a3ee5e6b4b0d3255bfef95601890afd80709", 0, "https://example.com/empty.json"
		);

		return new MinecraftVersionMeta(
				Collections.emptyMap(),       // arguments
				dummyAssetIndex,              // assetIndex
				"legacy",                     // assets
				0,                             // complianceLevel
				downloads,                     // downloads
				"unknown",                     // id
				Collections.emptyList(),       // libraries
				Collections.emptyMap(),        // logging
				"",                            // mainClass
				0,                             // minimumLauncherVersion
				"2025-01-01T00:00:00+00:00",  // releaseTime (modern, not legacy)
				"2025-01-01T00:00:00+00:00",  // time
				"release",                     // type
				new MinecraftVersionMeta.JavaVersion("java_major_version", 21) // javaVersion
		);
	}

	private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MinecraftMetadataProvider.class);

	public String getMinecraftVersion() {
		return options.minecraftVersion();
	}

	public boolean isFileDependency() {
		return fileDependency;
	}

	@Nullable
	public File getLocalMinecraftJar() {
		return localMinecraftJar;
	}

	public MinecraftVersionMeta getVersionMeta() {
		if (fileDependency) {
			return Objects.requireNonNull(syntheticVersionMeta, "Synthetic version meta not set for file dependency");
		}

		try {
			if (versionEntry == null) {
				versionEntry = getVersionEntry();
			}

			if (versionMeta == null) {
				versionMeta = readVersionMeta();
			}
		} catch (IOException e) {
			throw new UncheckedIOException(e.getMessage(), e);
		}

		return versionMeta;
	}

	public boolean isUnobfuscated() {
		return getVersionMeta().isVersionOrNewer(Constants.RELEASE_TIME_1_21_11_UNOBFUSCATED_SNAPSHOTS)
				&& !getVersionMeta().downloads().containsKey("client_mappings");
	}

	private ManifestEntryLocation getVersionEntry() throws IOException {
		// Custom URL always takes priority
		if (options.customManifestUrl() != null) {
			VersionsManifest.Version customVersion = new VersionsManifest.Version(
					options.minecraftVersion(),
					options.customManifestUrl()
			);
			return new ManifestEntryLocation(null, customVersion);
		}

		final List<ManifestEntrySupplier> suppliers = new ArrayList<>();

		// First try finding the version with caching
		for (ManifestLocation location : options.versionsManifests()) {
			suppliers.add(() -> getManifestEntry(location, false));
		}

		// Then force download the manifest to find the version
		for (ManifestLocation location : options.versionsManifests()) {
			suppliers.add(() -> getManifestEntry(location, true));
		}

		for (ManifestEntrySupplier supplier : suppliers) {
			final ManifestEntryLocation version = supplier.get();

			if (version != null) {
				return version;
			}
		}

		throw new RuntimeException("Failed to find minecraft version: " + options.minecraftVersion());
	}

	@Nullable
	private ManifestEntryLocation getManifestEntry(ManifestLocation location, boolean forceDownload) throws IOException {
		DownloadBuilder builder = download.apply(location.url());

		if (forceDownload) {
			builder = builder.forceDownload();
		} else {
			builder = builder.defaultCache();
		}

		final Path cacheFile = location.cacheFile(options.userCache());
		final String versionManifest = builder.downloadString(cacheFile);
		final VersionsManifest manifest = LoomGradlePlugin.GSON.fromJson(versionManifest, VersionsManifest.class);
		final VersionsManifest.Version version = manifest.getVersion(options.minecraftVersion());

		if (version != null) {
			return new ManifestEntryLocation(location, version);
		}

		return null;
	}

	private MinecraftVersionMeta readVersionMeta() throws IOException {
		final DownloadBuilder builder = download.apply(versionEntry.entry.url());

		if (versionEntry.entry.sha1() != null) {
			builder.sha1(versionEntry.entry.sha1());
		} else {
			builder.defaultCache();
		}

		final String fileName = getVersionMetaFileName();
		final Path cacheFile = options.workingDir().resolve(fileName);
		final String json = builder.downloadString(cacheFile);
		return LoomGradlePlugin.GSON.fromJson(json, MinecraftVersionMeta.class);
	}

	private String getVersionMetaFileName() {
		// custom version metadata
		if (versionEntry.manifest == null) {
			return "minecraft_info_" + Integer.toHexString(versionEntry.entry.url().hashCode()) + ".json";
		}

		// metadata url taken from versions manifest
		return versionEntry.manifest.name() + "_minecraft_info.json";
	}

	public record Options(String minecraftVersion,
					ManifestLocations versionsManifests,
					@Nullable String customManifestUrl,
					Path userCache,
					Path workingDir) {
		public static Options create(String minecraftVersion, Project project) {
			final LoomGradleExtension extension = LoomGradleExtension.get(project);
			final Path userCache = extension.getFiles().getUserCache().toPath();
			final Path workingDir = MinecraftProvider.minecraftWorkingDirectory(project, minecraftVersion).toPath();

			final ManifestLocations manifestLocations = extension.getVersionsManifests();
			final Property<String> customMetaUrl = extension.getCustomMinecraftMetadata();

			return new Options(
					minecraftVersion,
					manifestLocations,
					customMetaUrl.getOrNull(),
					userCache,
					workingDir
			);
		}
	}

	@FunctionalInterface
	private interface ManifestEntrySupplier {
		ManifestEntryLocation get() throws IOException;
	}

	private record ManifestEntryLocation(ManifestLocation manifest, VersionsManifest.Version entry) {
	}
}
