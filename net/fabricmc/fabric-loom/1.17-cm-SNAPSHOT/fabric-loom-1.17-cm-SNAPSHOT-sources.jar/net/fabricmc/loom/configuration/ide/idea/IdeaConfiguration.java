/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2021-2022 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.configuration.ide.idea;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.gradle.StartParameter;
import org.gradle.TaskExecutionRequest;
import org.gradle.api.Project;

import net.fabricmc.loom.LoomGradleExtension;
import net.fabricmc.loom.task.LoomTasks;

public abstract class IdeaConfiguration implements Runnable {
	@Inject
	protected abstract Project getProject();

	public void run() {
		getProject().getTasks().register("ideaSyncTask", IdeaSyncTask.class, task -> {
			if (LoomGradleExtension.get(getProject()).getRunConfigs().stream().anyMatch(config -> config.getGenerateRunConfig().get())) {
				task.dependsOn(LoomTasks.getIDELaunchConfigureTaskName(getProject()));
			} else {
				task.setEnabled(false);
			}
		});

		if (!IdeaUtils.isIdeaSync()) {
			return;
		}

		final StartParameter startParameter = getProject().getGradle().getStartParameter();
		final List<TaskExecutionRequest> taskRequests = new ArrayList<>(startParameter.getTaskRequests());

		// This doesnt overwrite any existing task requests, use Gradle to create a TaskExecutionRequest for us before adding it to the list of existing ones.
		startParameter.setTaskNames(List.of("ideaSyncTask"));
		taskRequests.addAll(startParameter.getTaskRequests());
		startParameter.setTaskRequests(taskRequests);
	}
}
