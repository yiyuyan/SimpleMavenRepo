package net.fabricmc.fabric.mixin.client.rendering;

import java.util.Map;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;

import net.fabricmc.fabric.impl.client.rendering.EntityRendererRegistryImpl;

@Mixin(EntityRenderers.class)
public abstract class EntityRenderersMixin {
	@Shadow()
	@Final
	private static Map<EntityType<?>, net.minecraft.client.renderer.entity.EntityRendererProvider<?>> PROVIDERS;

	@SuppressWarnings({"unchecked", "rawtypes"})
	@Inject(method = "<clinit>*", at = @At(value = "RETURN"))
	private static void onRegisterRenderers(CallbackInfo info) {
		EntityRendererRegistryImpl.setup(((t, factory) -> PROVIDERS.put(t, factory)));
	}
}
