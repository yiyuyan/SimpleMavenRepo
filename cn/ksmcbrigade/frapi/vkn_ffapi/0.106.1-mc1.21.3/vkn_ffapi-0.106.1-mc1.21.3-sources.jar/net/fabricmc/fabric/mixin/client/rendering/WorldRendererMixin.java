package net.fabricmc.fabric.mixin.client.rendering;

import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderBuffers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.InvalidateRenderStateCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.impl.client.rendering.WorldRenderContextImpl;

@Mixin(LevelRenderer.class)
public abstract class WorldRendererMixin {
	@Final
	@Shadow
	private RenderBuffers renderBuffers;
	@Shadow private ClientLevel level;
	@Final
	@Shadow
	private Minecraft minecraft;
	@Unique private final WorldRenderContextImpl context = new WorldRenderContextImpl();

	@Inject(method = "renderLevel", at = @At("HEAD"))
	private void beforeRender(GraphicsResourceAllocator allocator, DeltaTracker tickCounter, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightTexture lightmapTextureManager, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
		context.prepare((LevelRenderer) (Object) this, tickCounter, renderBlockOutline, camera, gameRenderer, lightmapTextureManager, projectionMatrix, positionMatrix, renderBuffers.bufferSource(), Minecraft.useShaderTransparency(), level);
		WorldRenderEvents.START.invoker().onStart(context);
	}

	@Inject(method = "renderLevel", at = @At("RETURN"))
	private void afterRender(GraphicsResourceAllocator allocator, DeltaTracker tickCounter, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightTexture lightmapTextureManager, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
		WorldRenderEvents.LAST.invoker().onLast(context);
		WorldRenderEvents.END.invoker().onEnd(context);
	}

	@Inject(method = "allChanged", at = @At("HEAD"))
	private void onReload(CallbackInfo ci) {
		InvalidateRenderStateCallback.EVENT.invoker().onInvalidate();
	}

	@Inject(method = "setupRender", at = @At("RETURN"))
	private void afterTerrainSetup(Camera camera, Frustum frustum, boolean hasForcedFrustum, boolean spectator, CallbackInfo ci) {
		context.setFrustum(frustum);
		WorldRenderEvents.AFTER_SETUP.invoker().afterSetup(context);
	}

	@Inject(method = "renderEntities", at = @At("HEAD"))
	private void beforeEntities(PoseStack poseStack, MultiBufferSource.BufferSource bufferSource, Camera camera, DeltaTracker tickCounter, java.util.List<net.minecraft.world.entity.Entity> entities, CallbackInfo ci) {
		context.setMatrixStack(poseStack);
		WorldRenderEvents.BEFORE_ENTITIES.invoker().beforeEntities(context);
	}

	@Inject(method = "renderBlockEntities", at = @At("HEAD"))
	private void afterEntities(PoseStack poseStack, MultiBufferSource.BufferSource bufferSource, MultiBufferSource.BufferSource crumblingBufferSource, Camera camera, float partialTick, CallbackInfo ci) {
		WorldRenderEvents.AFTER_ENTITIES.invoker().afterEntities(context);
	}

	@Inject(method = "renderBlockOutline", at = @At("HEAD"), cancellable = true)
	private void onDrawBlockOutline(Camera camera, MultiBufferSource.BufferSource bufferSource, PoseStack poseStack, boolean bl, CallbackInfo ci) {
		context.renderBlockOutline = WorldRenderEvents.BEFORE_BLOCK_OUTLINE.invoker().beforeBlockOutline(context, minecraft.hitResult);
		if (!context.renderBlockOutline) {
			ci.cancel();
		}
	}

	@Inject(method = "renderSectionLayer", at = @At("RETURN"))
	private void afterTranslucent(RenderType renderType, double d, double e, double g, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
		if (renderType == RenderType.translucent()) {
			WorldRenderEvents.AFTER_TRANSLUCENT.invoker().afterTranslucent(context);
		}
	}

	@Inject(method = "addLateDebugPass", at = @At("HEAD"))
	private void beforeDebugRender(com.mojang.blaze3d.framegraph.FrameGraphBuilder frameGraphBuilder, Vec3 vec3, net.minecraft.client.renderer.FogParameters fogParameters, CallbackInfo ci) {
		WorldRenderEvents.BEFORE_DEBUG_RENDER.invoker().beforeDebugRender(context);
	}

	@Inject(method = "addSkyPass", at = @At("HEAD"), cancellable = true)
	private void renderSky(com.mojang.blaze3d.framegraph.FrameGraphBuilder frameGraphBuilder, Camera camera, float f, net.minecraft.client.renderer.FogParameters fogParameters, CallbackInfo ci) {
		if (this.level != null) {
			DimensionRenderingRegistry.SkyRenderer renderer = DimensionRenderingRegistry.getSkyRenderer(level.dimension());
			if (renderer != null) {
				renderer.render(context);
				ci.cancel();
			}
		}
	}

	@Inject(method = "addCloudsPass", at = @At("HEAD"), cancellable = true)
	private void renderCloud(com.mojang.blaze3d.framegraph.FrameGraphBuilder frameGraphBuilder, Matrix4f matrix4f, Matrix4f matrix4f2, net.minecraft.client.CloudStatus cloudStatus, Vec3 vec3, float f, int i, float g, CallbackInfo ci) {
		if (this.level != null) {
			DimensionRenderingRegistry.CloudRenderer renderer = DimensionRenderingRegistry.getCloudRenderer(level.dimension());
			if (renderer != null) {
				renderer.render(context);
				ci.cancel();
			}
		}
	}

	@Inject(method = "addWeatherPass", at = @At("HEAD"), cancellable = true)
	private void renderWeather(com.mojang.blaze3d.framegraph.FrameGraphBuilder frameGraphBuilder, LightTexture lightTexture, Vec3 vec3, float f, net.minecraft.client.renderer.FogParameters fogParameters, CallbackInfo ci) {
		if (this.level != null) {
			DimensionRenderingRegistry.WeatherRenderer renderer = DimensionRenderingRegistry.getWeatherRenderer(level.dimension());
			if (renderer != null) {
				renderer.render(context);
				ci.cancel();
			}
		}
	}
}
