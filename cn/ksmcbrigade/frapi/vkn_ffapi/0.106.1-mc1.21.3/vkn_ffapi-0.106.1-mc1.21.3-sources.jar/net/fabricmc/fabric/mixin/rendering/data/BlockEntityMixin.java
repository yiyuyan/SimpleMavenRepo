package net.fabricmc.fabric.mixin.rendering.data;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.block.entity.BlockEntity;

import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachmentBlockEntity;

@Mixin(BlockEntity.class)
public class BlockEntityMixin implements RenderAttachmentBlockEntity, RenderDataBlockEntity {
    @Override
    @Nullable
    public Object getRenderAttachmentData() {
        return null;
    }

    @Override
    @Nullable
    public Object getRenderData() {
        return getRenderAttachmentData();
    }
}
