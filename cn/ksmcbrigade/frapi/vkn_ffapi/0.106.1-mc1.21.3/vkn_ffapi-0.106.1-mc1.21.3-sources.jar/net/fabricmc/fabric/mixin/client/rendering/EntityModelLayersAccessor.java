package net.fabricmc.fabric.mixin.client.rendering;

import java.util.Set;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;

@Mixin(ModelLayers.class)
public interface EntityModelLayersAccessor {
	@Accessor("ALL_MODELS")
	static Set<ModelLayerLocation> getLayers() {
		throw new AssertionError("This should not occur!");
	}
}
