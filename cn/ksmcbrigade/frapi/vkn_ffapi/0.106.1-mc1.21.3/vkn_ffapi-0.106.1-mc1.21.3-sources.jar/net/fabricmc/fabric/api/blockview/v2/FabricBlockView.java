package net.fabricmc.fabric.api.blockview.v2;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnknownNullability;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.entity.BlockEntity;

public interface FabricBlockView {
    @Nullable
    default Object getBlockEntityRenderData(BlockPos pos) {
        BlockEntity blockEntity = ((BlockGetter) this).getBlockEntity(pos);
        return blockEntity == null ? null : ((RenderDataBlockEntity) blockEntity).getRenderData();
    }

    default boolean hasBiomes() {
        return false;
    }

    @UnknownNullability
    default Holder<Biome> getBiomeFabric(BlockPos pos) {
        return null;
    }
}
