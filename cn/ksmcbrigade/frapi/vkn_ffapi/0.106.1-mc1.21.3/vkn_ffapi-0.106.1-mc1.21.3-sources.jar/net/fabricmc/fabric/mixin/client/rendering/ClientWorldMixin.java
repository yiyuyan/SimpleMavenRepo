package net.fabricmc.fabric.mixin.client.rendering;

import java.util.HashMap;
import java.util.Map;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.color.block.BlockTintCache;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ColorResolver;

import net.fabricmc.fabric.impl.client.rendering.ColorResolverRegistryImpl;

@Mixin(ClientLevel.class)
public class ClientWorldMixin {
	@Unique
	private final Map<ColorResolver, BlockTintCache> customTintCaches = new HashMap<>();

	@Inject(method = "getBlockTint", at = @At("HEAD"), cancellable = true)
	private void onGetBlockTint(BlockPos pos, ColorResolver resolver, CallbackInfoReturnable<Integer> cir) {
		if (ColorResolverRegistryImpl.isCustomResolver(resolver)) {
			BlockTintCache cache = customTintCaches.computeIfAbsent(resolver,
				r -> new BlockTintCache(p -> ((ClientLevel)(Object)this).calculateBlockTint(p, r)));
			cir.setReturnValue(cache.getColor(pos));
		}
	}

	@Inject(method = "onChunkLoaded", at = @At("RETURN"))
	private void onChunkLoaded(ChunkPos chunkPos, CallbackInfo ci) {
		for (BlockTintCache cache : customTintCaches.values()) {
			cache.invalidateForChunk(chunkPos.x, chunkPos.z);
		}
	}

	@Inject(method = "clearTintCaches", at = @At("TAIL"))
	private void onClearTintCaches(CallbackInfo ci) {
		for (BlockTintCache cache : customTintCaches.values()) {
			cache.invalidateAll();
		}
	}
}
