package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

@Deprecated
@FunctionalInterface
public interface BuiltinItemRenderer {
	void render(ItemStack stack, PoseStack matrices, MultiBufferSource vertexConsumers, int light, int overlay);
}
