package net.fabricmc.fabric.api.renderer.v1.mesh;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector3f;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.core.Direction;

import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;

public interface QuadView {
	int VANILLA_VERTEX_STRIDE = DefaultVertexFormat.BLOCK.getVertexSize() / 4;

	int VANILLA_QUAD_STRIDE = VANILLA_VERTEX_STRIDE * 4;

	float x(int vertexIndex);

	float y(int vertexIndex);

	float z(int vertexIndex);

	float posByIndex(int vertexIndex, int coordinateIndex);

	Vector3f copyPos(int vertexIndex, @Nullable Vector3f target);

	int color(int vertexIndex);

	float u(int vertexIndex);

	float v(int vertexIndex);

	Vector2f copyUv(int vertexIndex, @Nullable Vector2f target);

	int lightmap(int vertexIndex);

	boolean hasNormal(int vertexIndex);

	float normalX(int vertexIndex);

	float normalY(int vertexIndex);

	float normalZ(int vertexIndex);

	@Nullable
	Vector3f copyNormal(int vertexIndex, @Nullable Vector3f target);

	@Nullable
	Direction cullFace();

	@NotNull
	Direction lightFace();

	@Nullable
	Direction nominalFace();

	Vector3f faceNormal();

	RenderMaterial material();

	int colorIndex();

	int tag();

	void toVanilla(int[] target, int targetIndex);

	default BakedQuad toBakedQuad(TextureAtlasSprite sprite) {
		int[] vertexData = new int[VANILLA_QUAD_STRIDE];
		toVanilla(vertexData, 0);

		int outputColorIndex = material().disableColorIndex() ? -1 : colorIndex();
		boolean outputShade = !material().disableDiffuse();
		int outputLightEmission = 15;

		for (int i = 0; i < 4; i++) {
			int lightmap = lightmap(i);

			if (lightmap == 0) {
				outputLightEmission = 0;
				break;
			}

			int blockLight = LightTexture.block(lightmap);
			int skyLight = LightTexture.sky(lightmap);
			outputLightEmission = Math.min(outputLightEmission, Math.min(blockLight, skyLight));
		}

		return new BakedQuad(vertexData, outputColorIndex, lightFace(), sprite, outputShade, outputLightEmission);
	}

	@Deprecated
	default int spriteColor(int vertexIndex, int spriteIndex) {
		return color(vertexIndex);
	}

	@Deprecated
	default float spriteU(int vertexIndex, int spriteIndex) {
		return u(vertexIndex);
	}

	@Deprecated
	default float spriteV(int vertexIndex, int spriteIndex) {
		return v(vertexIndex);
	}

	@Deprecated
	default void copyTo(MutableQuadView target) {
		RenderMaterial material = target.material();
		target.copyFrom(this);
		target.material(material);
	}

	@Deprecated
	default void toVanilla(int spriteIndex, int[] target, int targetIndex, boolean isItem) {
		toVanilla(target, targetIndex);
	}

	@Deprecated
	default BakedQuad toBakedQuad(int spriteIndex, TextureAtlasSprite sprite, boolean isItem) {
		return toBakedQuad(sprite);
	}
}
