package net.fabricmc.fabric.api.renderer.v1.mesh;

import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector2fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.Direction;

import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;

public interface MutableQuadView extends QuadView {
	int BAKE_ROTATE_NONE = 0;

	int BAKE_ROTATE_90 = 1;

	int BAKE_ROTATE_180 = 2;

	int BAKE_ROTATE_270 = 3;

	int BAKE_LOCK_UV = 4;

	int BAKE_FLIP_U = 8;

	int BAKE_FLIP_V = 16;

	int BAKE_NORMALIZED = 32;

	MutableQuadView pos(int vertexIndex, float x, float y, float z);

	default MutableQuadView pos(int vertexIndex, Vector3f pos) {
		return pos(vertexIndex, pos.x, pos.y, pos.z);
	}

	default MutableQuadView pos(int vertexIndex, Vector3fc pos) {
		return pos(vertexIndex, pos.x(), pos.y(), pos.z());
	}

	MutableQuadView color(int vertexIndex, int color);

	default MutableQuadView color(int c0, int c1, int c2, int c3) {
		color(0, c0);
		color(1, c1);
		color(2, c2);
		color(3, c3);
		return this;
	}

	MutableQuadView uv(int vertexIndex, float u, float v);

	default MutableQuadView uv(int vertexIndex, Vector2f uv) {
		return uv(vertexIndex, uv.x, uv.y);
	}

	default MutableQuadView uv(int vertexIndex, Vector2fc uv) {
		return uv(vertexIndex, uv.x(), uv.y());
	}

	MutableQuadView spriteBake(TextureAtlasSprite sprite, int bakeFlags);

	MutableQuadView lightmap(int vertexIndex, int lightmap);

	default MutableQuadView lightmap(int b0, int b1, int b2, int b3) {
		lightmap(0, b0);
		lightmap(1, b1);
		lightmap(2, b2);
		lightmap(3, b3);
		return this;
	}

	MutableQuadView normal(int vertexIndex, float x, float y, float z);

	default MutableQuadView normal(int vertexIndex, Vector3f normal) {
		return normal(vertexIndex, normal.x, normal.y, normal.z);
	}

	default MutableQuadView normal(int vertexIndex, Vector3fc normal) {
		return normal(vertexIndex, normal.x(), normal.y(), normal.z());
	}

	MutableQuadView cullFace(@Nullable Direction face);

	MutableQuadView nominalFace(@Nullable Direction face);

	MutableQuadView material(RenderMaterial material);

	MutableQuadView colorIndex(int colorIndex);

	MutableQuadView tag(int tag);

	MutableQuadView copyFrom(QuadView quad);

	MutableQuadView fromVanilla(int[] quadData, int startIndex);

	MutableQuadView fromVanilla(BakedQuad quad, RenderMaterial material, @Nullable Direction cullFace);

	@Deprecated
	default MutableQuadView spriteColor(int vertexIndex, int spriteIndex, int color) {
		return color(vertexIndex, color);
	}

	@Deprecated
	default MutableQuadView spriteColor(int spriteIndex, int c0, int c1, int c2, int c3) {
		color(c0, c1, c2, c3);
		return this;
	}

	@Deprecated
	default MutableQuadView sprite(int vertexIndex, int spriteIndex, float u, float v) {
		return uv(vertexIndex, u, v);
	}

	@Deprecated
	default MutableQuadView spriteBake(int spriteIndex, TextureAtlasSprite sprite, int bakeFlags) {
		return spriteBake(sprite, bakeFlags);
	}

	@Deprecated
	default MutableQuadView fromVanilla(int[] quadData, int startIndex, boolean isItem) {
		return fromVanilla(quadData, startIndex);
	}
}
