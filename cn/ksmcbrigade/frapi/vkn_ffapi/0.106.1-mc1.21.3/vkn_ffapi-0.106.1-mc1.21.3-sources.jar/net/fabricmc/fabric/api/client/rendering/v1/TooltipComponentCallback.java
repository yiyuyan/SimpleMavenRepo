package net.fabricmc.fabric.api.client.rendering.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.inventory.tooltip.TooltipComponent;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

public interface TooltipComponentCallback {
	Event<TooltipComponentCallback> EVENT = EventFactory.createArrayBacked(TooltipComponentCallback.class, listeners -> data -> {
		for (TooltipComponentCallback listener : listeners) {
			ClientTooltipComponent component = listener.getComponent(data);

			if (component != null) {
				return component;
			}
		}

		return null;
	});

	@Nullable
	ClientTooltipComponent getComponent(TooltipComponent data);
}
