package net.fabricmc.fabric.mixin.blockview.client;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.client.renderer.chunk.RenderChunkRegion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;

import net.fabricmc.fabric.api.blockview.v2.FabricBlockView;
import net.fabricmc.fabric.impl.blockview.client.RenderDataMapConsumer;

@Mixin(RenderChunkRegion.class)
public abstract class ChunkRendererRegionMixin implements FabricBlockView, RenderDataMapConsumer {
    @Shadow
    @Final
    protected Level level;

    @Unique
    @Nullable
    private Long2ObjectMap<Object> fabric_renderDataMap;

    @Override
    public Object getBlockEntityRenderData(BlockPos pos) {
        return fabric_renderDataMap == null ? null : fabric_renderDataMap.get(pos.asLong());
    }

    @Override
    public void fabric_acceptRenderDataMap(Long2ObjectMap<Object> renderDataMap) {
        this.fabric_renderDataMap = renderDataMap;
    }

    @Override
    public boolean hasBiomes() {
        return true;
    }

    @Override
    public Holder<Biome> getBiomeFabric(BlockPos pos) {
        return level.getBiome(pos);
    }
}
