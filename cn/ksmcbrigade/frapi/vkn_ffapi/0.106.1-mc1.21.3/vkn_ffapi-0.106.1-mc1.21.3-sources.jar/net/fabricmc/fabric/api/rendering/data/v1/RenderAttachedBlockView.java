package net.fabricmc.fabric.api.rendering.data.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;

import net.fabricmc.fabric.api.blockview.v2.FabricBlockView;

@Deprecated
public interface RenderAttachedBlockView extends BlockAndTintGetter {
    @Deprecated
    @Nullable
    default Object getBlockEntityRenderAttachment(BlockPos pos) {
        return ((FabricBlockView) this).getBlockEntityRenderData(pos);
    }
}
