package net.fabricmc.fabric.api.renderer.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;

public interface Renderer {
	MeshBuilder meshBuilder();

	MaterialFinder materialFinder();

	@Nullable
	RenderMaterial materialById(ResourceLocation id);

	boolean registerMaterial(ResourceLocation id, RenderMaterial material);
}
