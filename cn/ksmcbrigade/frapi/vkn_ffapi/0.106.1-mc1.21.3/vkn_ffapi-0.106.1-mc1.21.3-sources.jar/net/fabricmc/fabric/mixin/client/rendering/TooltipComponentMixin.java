package net.fabricmc.fabric.mixin.client.rendering;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.inventory.tooltip.TooltipComponent;

import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;

@Mixin(ClientTooltipComponent.class)
public interface TooltipComponentMixin {
	@Inject(
			method = "create(Lnet/minecraft/world/inventory/tooltip/TooltipComponent;)Lnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipComponent;",
			at = @At("HEAD"),
			cancellable = true
	)
	private static void convertCustomTooltipData(TooltipComponent data, CallbackInfoReturnable<ClientTooltipComponent> cir) {
		ClientTooltipComponent component = TooltipComponentCallback.EVENT.invoker().getComponent(data);

		if (component != null) {
			cir.setReturnValue(component);
		}
	}
}
