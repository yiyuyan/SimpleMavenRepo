package net.fabricmc.fabric.api.renderer.v1.material;

import net.fabricmc.fabric.api.util.TriState;

public interface MaterialView {
	BlendMode blendMode();

	boolean disableColorIndex();

	boolean emissive();

	boolean disableDiffuse();

	TriState ambientOcclusion();

	TriState glint();

	ShadeMode shadeMode();
}
