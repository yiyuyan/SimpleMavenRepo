package net.fabricmc.fabric.impl.client.rendering;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.client.model.geom.ModelLayerLocation;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;

public final class EntityModelLayerImpl {
	public static final Map<ModelLayerLocation, EntityModelLayerRegistry.TexturedModelDataProvider> PROVIDERS = new HashMap<>();

	private EntityModelLayerImpl() {
	}
}
