package net.fabricmc.fabric.api.renderer.v1.model;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.resources.model.BakedModel;

public interface WrapperBakedModel {
	@Nullable
	BakedModel getWrappedModel();

	static BakedModel unwrap(BakedModel model) {
		while (model instanceof WrapperBakedModel wrapper) {
			BakedModel wrapped = wrapper.getWrappedModel();

			if (wrapped == null) {
				return model;
			} else if (wrapped == model) {
				throw new IllegalArgumentException("Model " + model + " is wrapping itself!");
			} else {
				model = wrapped;
			}
		}

		return model;
	}
}
