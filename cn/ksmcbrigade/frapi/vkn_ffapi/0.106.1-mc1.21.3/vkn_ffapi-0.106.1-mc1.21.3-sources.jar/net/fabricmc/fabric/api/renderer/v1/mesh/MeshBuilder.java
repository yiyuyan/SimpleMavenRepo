package net.fabricmc.fabric.api.renderer.v1.mesh;

public interface MeshBuilder {
	QuadEmitter getEmitter();

	Mesh build();
}
