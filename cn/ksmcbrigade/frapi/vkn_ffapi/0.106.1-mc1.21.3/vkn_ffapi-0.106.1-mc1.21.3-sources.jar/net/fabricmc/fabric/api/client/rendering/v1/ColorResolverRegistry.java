package net.fabricmc.fabric.api.client.rendering.v1;

import java.util.Set;

import org.jetbrains.annotations.UnmodifiableView;

import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.ColorResolver;

import net.fabricmc.fabric.impl.client.rendering.ColorResolverRegistryImpl;

public final class ColorResolverRegistry {
	private ColorResolverRegistry() {
	}

	public static void register(ColorResolver resolver) {
		ColorResolverRegistryImpl.register(resolver);
	}

	@UnmodifiableView
	public static Set<ColorResolver> getAllResolvers() {
		return ColorResolverRegistryImpl.getAllResolvers();
	}

	@UnmodifiableView
	public static Set<ColorResolver> getCustomResolvers() {
		return ColorResolverRegistryImpl.getCustomResolvers();
	}

	public static boolean isRegistered(ColorResolver resolver) {
		return getAllResolvers().contains(resolver);
	}
}
