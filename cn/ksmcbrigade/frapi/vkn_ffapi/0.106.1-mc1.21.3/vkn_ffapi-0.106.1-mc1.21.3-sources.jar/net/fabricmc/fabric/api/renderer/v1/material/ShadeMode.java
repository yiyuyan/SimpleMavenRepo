package net.fabricmc.fabric.api.renderer.v1.material;

public enum ShadeMode {
	ENHANCED,

	VANILLA;
}
