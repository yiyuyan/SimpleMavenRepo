package net.fabricmc.fabric.api.blockview.v2;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.entity.BlockEntity;

public interface RenderDataBlockEntity {
    @Nullable
    default Object getRenderData() {
        return null;
    }
}
