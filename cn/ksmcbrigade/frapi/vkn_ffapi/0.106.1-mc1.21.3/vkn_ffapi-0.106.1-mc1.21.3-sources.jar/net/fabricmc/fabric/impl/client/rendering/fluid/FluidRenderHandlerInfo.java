package net.fabricmc.fabric.impl.client.rendering.fluid;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.material.FluidState;

import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;

public class FluidRenderHandlerInfo {
	public final TextureAtlasSprite[] sprites = new TextureAtlasSprite[2];
	@Nullable
	public FluidRenderHandler handler;
	public boolean hasOverlay;
	public TextureAtlasSprite overlaySprite;

	public void setup(FluidRenderHandler handler, BlockAndTintGetter world, BlockPos pos, FluidState fluidState) {
		this.handler = handler;

		TextureAtlasSprite[] sprites = handler.getFluidSprites(world, pos, fluidState);

		this.sprites[0] = sprites[0];
		this.sprites[1] = sprites[1];

		if (sprites.length > 2) {
			hasOverlay = true;
			overlaySprite = sprites[2];
		}
	}

	public void clear() {
		sprites[0] = null;
		sprites[1] = null;
		handler = null;
		hasOverlay = false;
		overlaySprite = null;
	}
}
