package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import net.fabricmc.fabric.impl.client.rendering.EntityRendererRegistryImpl;

public final class EntityRendererRegistry {
	public static <E extends Entity> void register(EntityType<? extends E> entityType, EntityRendererProvider<E> entityRendererFactory) {
		EntityRendererRegistryImpl.register(entityType, entityRendererFactory);
	}

	private EntityRendererRegistry() {
	}
}
