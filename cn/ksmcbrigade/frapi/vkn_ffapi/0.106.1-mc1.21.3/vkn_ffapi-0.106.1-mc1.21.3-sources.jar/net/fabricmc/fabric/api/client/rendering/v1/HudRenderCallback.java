package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.DeltaTracker;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

public interface HudRenderCallback {
	Event<HudRenderCallback> EVENT = EventFactory.createArrayBacked(HudRenderCallback.class, (listeners) -> (guiGraphics, delta) -> {
		for (HudRenderCallback event : listeners) {
			event.onHudRender(guiGraphics, delta);
		}
	});

	void onHudRender(GuiGraphics guiGraphics, DeltaTracker deltaTracker);
}
