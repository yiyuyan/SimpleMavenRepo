package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.client.renderer.texture.atlas.SpriteSourceType;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.impl.client.rendering.AtlasSourceTypeRegistryImpl;

public final class AtlasSourceTypeRegistry {
	private AtlasSourceTypeRegistry() {
	}

	public static void register(ResourceLocation id, SpriteSourceType type) {
		AtlasSourceTypeRegistryImpl.register(id, type);
	}
}
