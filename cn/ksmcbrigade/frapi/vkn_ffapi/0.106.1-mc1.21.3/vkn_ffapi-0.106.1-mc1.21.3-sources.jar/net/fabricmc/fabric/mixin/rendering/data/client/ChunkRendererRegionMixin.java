package net.fabricmc.fabric.mixin.rendering.data.client;

import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.client.renderer.chunk.RenderChunkRegion;

import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;

@Mixin(RenderChunkRegion.class)
public abstract class ChunkRendererRegionMixin implements RenderAttachedBlockView {
}
