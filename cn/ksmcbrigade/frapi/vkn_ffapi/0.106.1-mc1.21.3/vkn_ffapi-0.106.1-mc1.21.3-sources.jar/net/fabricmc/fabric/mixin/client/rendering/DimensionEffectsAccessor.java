package net.fabricmc.fabric.mixin.client.rendering;

import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.resources.ResourceLocation;

@Mixin(DimensionSpecialEffects.class)
public interface DimensionEffectsAccessor {
	@Accessor("EFFECTS")
	static Object2ObjectMap<ResourceLocation, DimensionSpecialEffects> getIdentifierMap() {
		throw new AssertionError("This should not occur!");
	}
}
