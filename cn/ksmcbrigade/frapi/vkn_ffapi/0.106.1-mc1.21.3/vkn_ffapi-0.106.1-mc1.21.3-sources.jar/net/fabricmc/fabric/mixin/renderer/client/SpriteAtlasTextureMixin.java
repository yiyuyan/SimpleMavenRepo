package net.fabricmc.fabric.mixin.renderer.client;

import java.util.Map;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.renderer.texture.SpriteLoader;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.impl.renderer.SpriteFinderImpl;

@Mixin(TextureAtlas.class)
public class SpriteAtlasTextureMixin implements SpriteFinderImpl.SpriteFinderAccess {
	@Final
	@Shadow
	private Map<ResourceLocation, TextureAtlasSprite> texturesByName;

	private SpriteFinderImpl fabric_spriteFinder = null;

	@Inject(at = @At("RETURN"), method = "upload")
	private void uploadHook(SpriteLoader.Preparations preparations, CallbackInfo ci) {
		fabric_spriteFinder = null;
	}

	@Override
	public SpriteFinderImpl fabric_spriteFinder() {
		SpriteFinderImpl result = fabric_spriteFinder;

		if (result == null) {
			result = new SpriteFinderImpl(texturesByName, (TextureAtlas) (Object) this);
			fabric_spriteFinder = result;
		}

		return result;
	}
}
