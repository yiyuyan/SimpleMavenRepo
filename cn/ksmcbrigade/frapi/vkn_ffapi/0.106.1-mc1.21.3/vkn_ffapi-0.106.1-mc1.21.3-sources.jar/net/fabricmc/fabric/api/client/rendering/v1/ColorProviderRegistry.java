package net.fabricmc.fabric.api.client.rendering.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.level.block.Block;
import net.minecraft.client.color.block.BlockColor;
import net.minecraft.client.color.item.ItemColor;
import net.minecraft.world.level.ItemLike;

import net.fabricmc.fabric.impl.client.rendering.ColorProviderRegistryImpl;

public interface ColorProviderRegistry<T, Provider> {
	ColorProviderRegistry<ItemLike, ItemColor> ITEM = ColorProviderRegistryImpl.ITEM;

	ColorProviderRegistry<Block, BlockColor> BLOCK = ColorProviderRegistryImpl.BLOCK;

	@SuppressWarnings("unchecked")
	void register(Provider provider, T... objects);

	@Nullable
	Provider get(T object);
}
