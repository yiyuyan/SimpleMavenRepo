package net.fabricmc.fabric.impl.client.rendering;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry.CloudRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry.SkyRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry.WeatherRenderer;
import net.fabricmc.fabric.mixin.client.rendering.DimensionEffectsAccessor;

public final class DimensionRenderingRegistryImpl {
	private static final Map<ResourceKey<Level>, SkyRenderer> SKY_RENDERERS = new IdentityHashMap<>();
	private static final Map<ResourceKey<Level>, CloudRenderer> CLOUD_RENDERERS = new IdentityHashMap<>();
	private static final Map<ResourceKey<Level>, WeatherRenderer> WEATHER_RENDERERS = new IdentityHashMap<>();

	public static void registerSkyRenderer(ResourceKey<Level> key, SkyRenderer renderer) {
		Objects.requireNonNull(key);
		Objects.requireNonNull(renderer);

		SKY_RENDERERS.putIfAbsent(key, renderer);
	}

	public static void registerWeatherRenderer(ResourceKey<Level> key, WeatherRenderer renderer) {
		Objects.requireNonNull(key);
		Objects.requireNonNull(renderer);

		WEATHER_RENDERERS.putIfAbsent(key, renderer);
	}

	public static void registerDimensionEffects(ResourceLocation key, DimensionSpecialEffects effects) {
		Objects.requireNonNull(key);
		Objects.requireNonNull(effects);
		//The map containing all dimension effects returns a default if null so a null check doesn't work.

		DimensionEffectsAccessor.getIdentifierMap().putIfAbsent(key, effects);
	}

	public static void registerCloudRenderer(ResourceKey<Level> key, CloudRenderer renderer) {
		Objects.requireNonNull(key);
		Objects.requireNonNull(renderer);

		CLOUD_RENDERERS.putIfAbsent(key, renderer);
	}

	@Nullable
	public static SkyRenderer getSkyRenderer(ResourceKey<Level> key) {
		return SKY_RENDERERS.get(key);
	}

	@Nullable
	public static CloudRenderer getCloudRenderer(ResourceKey<Level> key) {
		return CLOUD_RENDERERS.get(key);
	}

	@Nullable
	public static WeatherRenderer getWeatherRenderer(ResourceKey<Level> key) {
		return WEATHER_RENDERERS.get(key);
	}

	@Nullable
	public static DimensionSpecialEffects getDimensionEffects(ResourceLocation key) {
		return DimensionEffectsAccessor.getIdentifierMap().get(key);
	}
}
