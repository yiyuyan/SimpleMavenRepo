package net.fabricmc.fabric.api.renderer.v1.material;

import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;

public interface RenderMaterial extends MaterialView {
	ResourceLocation MATERIAL_STANDARD = ResourceLocation.parse("fabric:standard");

	@Deprecated
	default int spriteDepth() {
		return 1;
	}
}
