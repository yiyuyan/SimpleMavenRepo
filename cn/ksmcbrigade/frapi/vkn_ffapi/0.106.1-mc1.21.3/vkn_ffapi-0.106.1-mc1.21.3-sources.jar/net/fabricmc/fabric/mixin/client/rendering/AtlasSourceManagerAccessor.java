package net.fabricmc.fabric.mixin.client.rendering;

import com.google.common.collect.BiMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.client.renderer.texture.atlas.SpriteSourceType;
import net.minecraft.client.renderer.texture.atlas.SpriteSources;
import net.minecraft.resources.ResourceLocation;

@Mixin(SpriteSources.class)
public interface AtlasSourceManagerAccessor {
	@Accessor("TYPES")
	static BiMap<ResourceLocation, SpriteSourceType> getSourceTypeById() {
		throw new AssertionError();
	}
}
