package net.fabricmc.fabric.api.renderer.v1.render;

import java.util.function.Consumer;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;

import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;

public interface RenderContext {
	QuadEmitter getEmitter();

	boolean hasTransform();

	void pushTransform(QuadTransform transform);

	void popTransform();

	boolean isFaceCulled(@Nullable Direction face);

	ItemDisplayContext itemTransformationMode();

	@FunctionalInterface
	interface QuadTransform {
		boolean transform(MutableQuadView quad);
	}

	@Deprecated
	default Consumer<Mesh> meshConsumer() {
		return mesh -> mesh.outputTo(getEmitter());
	}
}
