package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;

import net.fabricmc.fabric.impl.client.rendering.BlockEntityRendererRegistryImpl;

@Deprecated
public final class BlockEntityRendererRegistry {
	public static <E extends BlockEntity> void register(BlockEntityType<E> blockEntityType, BlockEntityRendererProvider<? super E> blockEntityRendererFactory) {
		BlockEntityRendererRegistryImpl.register(blockEntityType, blockEntityRendererFactory);
	}

	private BlockEntityRendererRegistry() {
	}
}
