package net.fabricmc.fabric.api.renderer.v1.material;

import net.minecraft.client.renderer.RenderType;

public enum BlendMode {
	DEFAULT(null),

	SOLID(RenderType.solid()),

	CUTOUT_MIPPED(RenderType.cutoutMipped()),

	CUTOUT(RenderType.cutout()),

	TRANSLUCENT(RenderType.translucent());

	public final RenderType blockRenderLayer;

	BlendMode(RenderType blockRenderLayer) {
		this.blockRenderLayer = blockRenderLayer;
	}

	public static BlendMode fromRenderLayer(RenderType renderLayer) {
		if (renderLayer == RenderType.solid()) {
			return SOLID;
		} else if (renderLayer == RenderType.cutoutMipped()) {
			return CUTOUT_MIPPED;
		} else if (renderLayer == RenderType.cutout()) {
			return CUTOUT;
		} else if (renderLayer == RenderType.translucent()) {
			return TRANSLUCENT;
		} else {
			return DEFAULT;
		}
	}
}
