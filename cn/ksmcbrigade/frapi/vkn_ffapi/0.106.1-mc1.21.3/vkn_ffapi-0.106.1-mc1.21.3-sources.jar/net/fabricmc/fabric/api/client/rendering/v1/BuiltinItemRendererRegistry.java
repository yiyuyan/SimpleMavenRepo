package net.fabricmc.fabric.api.client.rendering.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;

import net.fabricmc.fabric.impl.client.rendering.BuiltinItemRendererRegistryImpl;

public interface BuiltinItemRendererRegistry {
	BuiltinItemRendererRegistry INSTANCE = new BuiltinItemRendererRegistryImpl();

	@Deprecated
	void register(Item item, BuiltinItemRenderer renderer);

	@Deprecated
	void register(ItemLike item, BuiltinItemRenderer renderer);

	void register(ItemLike item, DynamicItemRenderer renderer);

	@Nullable
	DynamicItemRenderer get(ItemLike item);

	@FunctionalInterface
	interface DynamicItemRenderer {
		void render(ItemStack stack, ItemDisplayContext mode, PoseStack matrices, MultiBufferSource vertexConsumers, int light, int overlay);
	}
}
