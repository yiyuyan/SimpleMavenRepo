package net.fabricmc.fabric.api.client.rendering.v1;

import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

public final class LivingEntityFeatureRenderEvents {
	public static final Event<AllowCapeRender> ALLOW_CAPE_RENDER = EventFactory.createArrayBacked(AllowCapeRender.class, listeners -> state -> {
		for (AllowCapeRender listener : listeners) {
			if (!listener.allowCapeRender(state)) {
				return false;
			}
		}

		return true;
	});

	@FunctionalInterface
	public interface AllowCapeRender {
		boolean allowCapeRender(PlayerRenderState state);
	}

	private LivingEntityFeatureRenderEvents() {
	}
}
