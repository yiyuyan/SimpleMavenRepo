package net.fabricmc.fabric.api.renderer.v1;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import net.fabricmc.fabric.impl.renderer.RendererAccessImpl;

@ApiStatus.NonExtendable
public interface RendererAccess {
	RendererAccess INSTANCE = RendererAccessImpl.INSTANCE;

	void registerRenderer(Renderer plugin);

	@Nullable
	Renderer getRenderer();

	boolean hasRenderer();
}
