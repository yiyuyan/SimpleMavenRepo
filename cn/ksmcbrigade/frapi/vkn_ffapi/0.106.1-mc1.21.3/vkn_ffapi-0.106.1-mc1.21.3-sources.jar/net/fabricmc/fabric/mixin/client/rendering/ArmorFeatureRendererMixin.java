package net.fabricmc.fabric.mixin.client.rendering;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;

import net.fabricmc.fabric.impl.client.rendering.ArmorRendererRegistryImpl;

@Mixin(HumanoidArmorLayer.class)
public abstract class ArmorFeatureRendererMixin {
	@Unique
	private HumanoidRenderState bipedRenderState;

	@Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V", at = @At("HEAD"))
	private void render(PoseStack matrixStack, MultiBufferSource vertexConsumerProvider, int i, HumanoidRenderState humanoidRenderState, float f, float g, CallbackInfo ci) {
		this.bipedRenderState = humanoidRenderState;
	}
}
