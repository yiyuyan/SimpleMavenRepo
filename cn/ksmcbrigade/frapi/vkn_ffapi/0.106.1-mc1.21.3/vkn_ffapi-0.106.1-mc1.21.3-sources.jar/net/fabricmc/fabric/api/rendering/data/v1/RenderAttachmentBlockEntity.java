package net.fabricmc.fabric.api.rendering.data.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.level.block.entity.BlockEntity;

import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;

@Deprecated
@FunctionalInterface
public interface RenderAttachmentBlockEntity {
    @Deprecated
    @Nullable
    Object getRenderAttachmentData();
}
