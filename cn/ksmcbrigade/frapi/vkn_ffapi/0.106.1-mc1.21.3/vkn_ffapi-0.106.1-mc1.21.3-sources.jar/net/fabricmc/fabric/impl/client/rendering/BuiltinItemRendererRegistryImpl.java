package net.fabricmc.fabric.impl.client.rendering;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.core.registries.BuiltInRegistries;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;

public final class BuiltinItemRendererRegistryImpl implements BuiltinItemRendererRegistry {
	private static final Map<Item, DynamicItemRenderer> RENDERERS = new HashMap<>();

	public BuiltinItemRendererRegistryImpl() {
	}

	@Override
	public void register(Item item, BuiltinItemRenderer renderer) {
		Objects.requireNonNull(renderer, "renderer is null");
		this.register(item, (DynamicItemRenderer) (stack, mode, matrices, vertexConsumers, light, overlay) -> renderer.render(stack, matrices, vertexConsumers, light, overlay));
	}

	@Override
	public void register(ItemLike item, BuiltinItemRenderer renderer) {
		Objects.requireNonNull(item, "item is null");
		register(item.asItem(), renderer);
	}

	@Override
	public void register(ItemLike item, DynamicItemRenderer renderer) {
		Objects.requireNonNull(item, "item is null");
		Objects.requireNonNull(item.asItem(), "item is null");
		Objects.requireNonNull(renderer, "renderer is null");

		if (RENDERERS.putIfAbsent(item.asItem(), renderer) != null) {
			throw new IllegalArgumentException("Item " + BuiltInRegistries.ITEM.getKey(item.asItem()) + " already has a builtin renderer!");
		}
	}

	@Override
	@Nullable
	public DynamicItemRenderer get(ItemLike item) {
		Objects.requireNonNull(item.asItem(), "item is null");

		return RENDERERS.get(item.asItem());
	}
}
