package net.fabricmc.fabric.mixin.renderer.client;

import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.client.resources.model.BakedModel;

import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;

@Mixin(BakedModel.class)
public interface BakedModelMixin extends FabricBakedModel {
}
