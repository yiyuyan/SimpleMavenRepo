package net.fabricmc.fabric.mixin.renderer.client;

import java.util.function.Supplier;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.WeightedBakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.SimpleWeightedRandomList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;

import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;

@Mixin(WeightedBakedModel.class)
public class WeightedBakedModelMixin implements FabricBakedModel {
	@Shadow
	@Final
	private SimpleWeightedRandomList<BakedModel> list;

	@Override
	public void emitBlockQuads(BlockAndTintGetter blockView, BlockState state, BlockPos pos, Supplier<RandomSource> randomSupplier, RenderContext context) {
		list.getRandomValue(randomSupplier.get()).ifPresent(model -> {
			((FabricBakedModel) model).emitBlockQuads(blockView, state, pos, () -> {
				RandomSource random = randomSupplier.get();
				random.nextInt();
				return random;
			}, context);
		});
	}

	@Override
	public void emitItemQuads(ItemStack stack, Supplier<RandomSource> randomSupplier, RenderContext context) {
		list.getRandomValue(randomSupplier.get()).ifPresent(model -> {
			((FabricBakedModel) model).emitItemQuads(stack, () -> {
				RandomSource random = randomSupplier.get();
				random.nextInt();
				return random;
			}, context);
		});
	}
}
