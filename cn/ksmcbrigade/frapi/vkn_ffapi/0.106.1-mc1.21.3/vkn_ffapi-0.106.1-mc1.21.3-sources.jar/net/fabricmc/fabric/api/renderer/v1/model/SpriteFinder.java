package net.fabricmc.fabric.api.renderer.v1.model;

import org.jetbrains.annotations.ApiStatus;

import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.impl.renderer.SpriteFinderImpl;

@ApiStatus.NonExtendable
public interface SpriteFinder {
	static SpriteFinder get(TextureAtlas atlas) {
		return SpriteFinderImpl.get(atlas);
	}

	TextureAtlasSprite find(QuadView quad);

	TextureAtlasSprite find(float u, float v);

	@Deprecated
	default TextureAtlasSprite find(QuadView quad, int textureIndex) {
		return find(quad);
	}
}
