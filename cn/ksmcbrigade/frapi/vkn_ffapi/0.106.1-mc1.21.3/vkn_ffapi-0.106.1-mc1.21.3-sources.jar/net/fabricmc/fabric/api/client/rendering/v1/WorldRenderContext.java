package net.fabricmc.fabric.api.client.rendering.v1;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.DeltaTracker;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LevelRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public interface WorldRenderContext {
	LevelRenderer worldRenderer();

	@Nullable
	PoseStack matrixStack();

	DeltaTracker tickCounter();

	boolean blockOutlines();

	Camera camera();

	GameRenderer gameRenderer();

	LightTexture lightmapTextureManager();

	Matrix4f projectionMatrix();

	Matrix4f positionMatrix();

	ClientLevel world();

	boolean advancedTranslucency();

	@Nullable MultiBufferSource consumers();

	@Nullable Frustum frustum();

	interface BlockOutlineContext {
		@Deprecated
		VertexConsumer vertexConsumer();

		Entity entity();

		double cameraX();

		double cameraY();

		double cameraZ();

		BlockPos blockPos();

		BlockState blockState();
	}
}
