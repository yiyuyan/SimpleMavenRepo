package net.fabricmc.fabric.mixin.client.rendering.fluid;

import java.util.Arrays;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.block.LiquidBlockRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;

import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerInfo;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerRegistryImpl;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderingImpl;

@Mixin(LiquidBlockRenderer.class)
public class FluidRendererMixin {
	@Final
	@Shadow
	private TextureAtlasSprite[] lavaIcons;
	@Final
	@Shadow
	private TextureAtlasSprite[] waterIcons;
	@Shadow
	private TextureAtlasSprite waterOverlay;

	private final ThreadLocal<Block> fabric_neighborBlock = new ThreadLocal<>();

	@Inject(at = @At("RETURN"), method = "setupSprites")
	public void onResourceReloadReturn(CallbackInfo info) {
		LiquidBlockRenderer self = (LiquidBlockRenderer) (Object) this;
		((FluidRenderHandlerRegistryImpl) FluidRenderHandlerRegistry.INSTANCE).onFluidRendererReload(self, waterIcons, lavaIcons, waterOverlay);
	}

	@Inject(at = @At("HEAD"), method = "tesselate", cancellable = true)
	public void onHeadRender(BlockAndTintGetter view, BlockPos pos, VertexConsumer vertexConsumer, BlockState blockState, FluidState fluidState, CallbackInfo ci) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();

		if (info.handler == null) {
			FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(fluidState.getType());

			if (handler != null) {
				handler.renderFluid(pos, view, vertexConsumer, blockState, fluidState);
				ci.cancel();
			}
		}
	}

	@ModifyVariable(at = @At("STORE"), method = "tesselate", ordinal = 0)
	public boolean modLavaCheck(boolean chk) {
		final FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		return info.handler != null ? !info.hasOverlay : chk;
	}

	@ModifyVariable(at = @At("STORE"), method = "tesselate", ordinal = 0)
	public TextureAtlasSprite[] modSpriteArray(TextureAtlasSprite[] chk) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		if (info.handler != null) {
			TextureAtlasSprite[] sprites = info.sprites;
			if (sprites.length < 3) {
				sprites = Arrays.copyOf(sprites, 3);
			}
			return sprites;
		}
		return chk;
	}

	@Redirect(at = @At(value = "INVOKE", target = "Lnet/neoforged/neoforge/client/extensions/common/IClientFluidTypeExtensions;getTintColor(Lnet/minecraft/world/level/material/FluidState;Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/core/BlockPos;)I", remap = false), method = "tesselate")
	public int modTintColor(IClientFluidTypeExtensions extensions, FluidState fluidState, BlockAndTintGetter level, BlockPos pos) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		if (info.handler != null) {
			return info.handler.getFluidColor(level, pos, fluidState);
		}
		return extensions.getTintColor(fluidState, level, pos);
	}

	@Redirect(at = @At(value = "FIELD", opcode = Opcodes.GETFIELD, target = "Lnet/minecraft/client/renderer/block/LiquidBlockRenderer;waterOverlay:Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;", remap = false), method = "tesselate", require = 0)
	public TextureAtlasSprite modWaterOverlaySprite(LiquidBlockRenderer self) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		return info.handler != null && info.hasOverlay ? info.overlaySprite : waterOverlay;
	}

	@Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", remap = false), method = "tesselate", require = 0)
	public Block getOverlayBlock(BlockState state) {
		Block block = state.getBlock();
		fabric_neighborBlock.set(block);
		return null;
	}

	@ModifyVariable(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", shift = At.Shift.BY, by = 2, remap = false), method = "tesselate", ordinal = 0, require = 0)
	public TextureAtlasSprite modSideSpriteForOverlay(TextureAtlasSprite chk) {
		Block block = fabric_neighborBlock.get();

		if (FluidRenderHandlerRegistry.INSTANCE.isBlockTransparent(block)) {
			FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
			return info.handler != null && info.hasOverlay ? info.overlaySprite : waterOverlay;
		}

		return chk;
	}
}
