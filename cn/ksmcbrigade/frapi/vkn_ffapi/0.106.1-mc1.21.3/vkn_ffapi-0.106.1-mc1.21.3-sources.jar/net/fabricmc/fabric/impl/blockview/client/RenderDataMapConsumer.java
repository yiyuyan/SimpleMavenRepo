package net.fabricmc.fabric.impl.blockview.client;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

public interface RenderDataMapConsumer {
    void fabric_acceptRenderDataMap(Long2ObjectMap<Object> renderDataMap);
}
