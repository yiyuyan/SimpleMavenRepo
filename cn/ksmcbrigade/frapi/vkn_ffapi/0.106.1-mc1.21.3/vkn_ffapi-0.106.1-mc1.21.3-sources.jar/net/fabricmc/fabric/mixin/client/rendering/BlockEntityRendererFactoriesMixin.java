package net.fabricmc.fabric.mixin.client.rendering;

import java.util.Map;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.entity.BlockEntityType;

import net.fabricmc.fabric.impl.client.rendering.BlockEntityRendererRegistryImpl;

@Mixin(BlockEntityRenderers.class)
public abstract class BlockEntityRendererFactoriesMixin {
	@Shadow()
	@Final
	private static Map<BlockEntityType<?>, BlockEntityRendererProvider<?>> PROVIDERS;

	@Inject(at = @At("RETURN"), method = "<clinit>*")
	private static void init(CallbackInfo ci) {
		BlockEntityRendererRegistryImpl.setup(((t, factory) -> PROVIDERS.put(t, factory)));
	}
}
