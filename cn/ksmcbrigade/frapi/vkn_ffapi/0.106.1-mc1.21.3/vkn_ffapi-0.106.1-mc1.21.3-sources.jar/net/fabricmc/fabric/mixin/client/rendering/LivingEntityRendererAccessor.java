package net.fabricmc.fabric.mixin.client.rendering;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

@Mixin(LivingEntityRenderer.class)
public interface LivingEntityRendererAccessor<T extends net.minecraft.world.entity.LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> {
	@Invoker("addLayer")
	boolean callAddLayer(RenderLayer<S, M> featureRenderer);
}
