package net.fabricmc.fabric.impl.client.rendering;

import java.util.HashMap;
import java.util.function.BiConsumer;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;

public final class BlockEntityRendererRegistryImpl {
	private static final HashMap<BlockEntityType<?>, BlockEntityRendererProvider<?>> MAP = new HashMap<>();
	private static BiConsumer<BlockEntityType<?>, BlockEntityRendererProvider<?>> handler = (type, function) -> MAP.put(type, function);

	public static <E extends BlockEntity> void register(BlockEntityType<E> blockEntityType, BlockEntityRendererProvider<? super E> blockEntityRendererFactory) {
		handler.accept(blockEntityType, blockEntityRendererFactory);
	}

	public static void setup(BiConsumer<BlockEntityType<?>, BlockEntityRendererProvider<?>> vanillaHandler) {
		MAP.forEach(vanillaHandler);
		handler = vanillaHandler;
	}

	private BlockEntityRendererRegistryImpl() {
	}
}
