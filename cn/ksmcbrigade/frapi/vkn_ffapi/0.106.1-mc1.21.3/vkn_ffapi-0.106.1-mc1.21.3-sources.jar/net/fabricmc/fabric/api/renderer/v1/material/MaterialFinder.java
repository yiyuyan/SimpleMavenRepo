package net.fabricmc.fabric.api.renderer.v1.material;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.util.TriState;

public interface MaterialFinder extends MaterialView {
	MaterialFinder blendMode(BlendMode blendMode);

	MaterialFinder disableColorIndex(boolean disable);

	MaterialFinder emissive(boolean isEmissive);

	MaterialFinder disableDiffuse(boolean disable);

	MaterialFinder ambientOcclusion(TriState mode);

	MaterialFinder glint(TriState mode);

	MaterialFinder shadeMode(ShadeMode mode);

	MaterialFinder copyFrom(MaterialView material);

	MaterialFinder clear();

	RenderMaterial find();

	@Deprecated
	default MaterialFinder blendMode(int spriteIndex, RenderType renderLayer) {
		return blendMode(BlendMode.fromRenderLayer(renderLayer));
	}

	@Deprecated
	default MaterialFinder blendMode(int spriteIndex, BlendMode blendMode) {
		if (blendMode == null) {
			blendMode = BlendMode.DEFAULT;
		}

		return blendMode(blendMode);
	}

	@Deprecated
	default MaterialFinder disableColorIndex(int spriteIndex, boolean disable) {
		return disableColorIndex(disable);
	}

	@Deprecated
	default MaterialFinder emissive(int spriteIndex, boolean isEmissive) {
		return emissive(isEmissive);
	}

	@Deprecated
	default MaterialFinder disableDiffuse(int spriteIndex, boolean disable) {
		return disableDiffuse(disable);
	}

	@Deprecated
	default MaterialFinder disableAo(int spriteIndex, boolean disable) {
		return ambientOcclusion(disable ? TriState.FALSE : TriState.DEFAULT);
	}

	@Deprecated
	default MaterialFinder spriteDepth(int depth) {
		return this;
	}
}
