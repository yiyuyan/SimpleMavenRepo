package net.fabricmc.fabric.impl.renderer;

import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;

public final class RendererAccessImpl implements RendererAccess {
	public static final RendererAccessImpl INSTANCE = new RendererAccessImpl();

	private RendererAccessImpl() { }

	@Override
	public void registerRenderer(Renderer renderer) {
		if (renderer == null) {
			throw new NullPointerException("Attempt to register a NULL rendering plug-in.");
		} else if (activeRenderer != null) {
			throw new UnsupportedOperationException("A second rendering plug-in attempted to register. Multiple rendering plug-ins are not supported.");
		} else {
			activeRenderer = renderer;
			hasActiveRenderer = true;
		}
	}

	private Renderer activeRenderer = null;

	private boolean hasActiveRenderer = false;

	@Override
	public Renderer getRenderer() {
		return activeRenderer;
	}

	@Override
	public boolean hasRenderer() {
		return hasActiveRenderer;
	}
}
