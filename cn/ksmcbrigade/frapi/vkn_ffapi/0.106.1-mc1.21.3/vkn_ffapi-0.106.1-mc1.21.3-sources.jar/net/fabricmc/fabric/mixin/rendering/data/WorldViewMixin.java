package net.fabricmc.fabric.mixin.rendering.data;

import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.LevelReader;

import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;

@Mixin(LevelReader.class)
public interface WorldViewMixin extends RenderAttachedBlockView {
}
