package net.fabricmc.fabric.mixin.blockview.client;

import java.util.Map;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;
import net.fabricmc.fabric.impl.blockview.client.RenderDataMapConsumer;
import net.minecraft.client.renderer.chunk.RenderRegionCache;
import net.minecraft.client.renderer.chunk.RenderChunkRegion;

@Mixin(RenderRegionCache.class)
public abstract class ChunkRendererRegionBuilderMixin {
    @Inject(method = "createRegion", at = @At("RETURN"))
    private void onRegionCreated(Level level, SectionPos sectionPos, CallbackInfoReturnable<RenderChunkRegion> cir) {
        RenderChunkRegion region = cir.getReturnValue();
        if (region == null) return;

        Long2ObjectOpenHashMap<Object> map = null;

        int secX = sectionPos.getX();
        int secY = sectionPos.getY();
        int secZ = sectionPos.getZ();

        int xMin = (secX - 1) << 4;
        int yMin = (secY - 1) << 4;
        int zMin = (secZ - 1) << 4;
        int xMax = ((secX + 1) << 4) + 15;
        int yMax = ((secY + 1) << 4) + 15;
        int zMax = ((secZ + 1) << 4) + 15;

        for (int x = secX - 1; x <= secX + 1; x++) {
            for (int z = secZ - 1; z <= secZ + 1; z++) {
                LevelChunk chunk = level.getChunk(x, z);
                map = collectData(chunk, xMin, yMin, zMin, xMax, yMax, zMax, map);
            }
        }

        if (map != null) {
            ((RenderDataMapConsumer) region).fabric_acceptRenderDataMap(map);
        }
    }

    @Unique
    private static Long2ObjectOpenHashMap<Object> collectData(LevelChunk chunk, int xMin, int yMin, int zMin, int xMax, int yMax, int zMax, Long2ObjectOpenHashMap<Object> map) {
        if (chunk.getBlockEntities().isEmpty()) {
            return map;
        }

        for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
            BlockPos pos = entry.getKey();
            if (pos.getX() >= xMin && pos.getX() <= xMax
                    && pos.getY() >= yMin && pos.getY() <= yMax
                    && pos.getZ() >= zMin && pos.getZ() <= zMax) {
                Object data = ((RenderDataBlockEntity) entry.getValue()).getRenderData();
                if (data != null) {
                    if (map == null) {
                        map = new Long2ObjectOpenHashMap<>();
                    }
                    map.put(pos.asLong(), data);
                }
            }
        }

        return map;
    }
}
