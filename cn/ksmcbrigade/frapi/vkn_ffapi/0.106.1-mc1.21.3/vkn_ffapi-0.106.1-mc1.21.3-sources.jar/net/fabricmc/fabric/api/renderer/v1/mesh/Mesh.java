package net.fabricmc.fabric.api.renderer.v1.mesh;

import java.util.function.Consumer;

import net.fabricmc.fabric.api.renderer.v1.Renderer;

public interface Mesh {
	void forEach(Consumer<QuadView> consumer);

	void outputTo(QuadEmitter emitter);
}
