package net.fabricmc.fabric.api.client.rendering.v1;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import net.fabricmc.fabric.impl.client.rendering.DimensionRenderingRegistryImpl;

public interface DimensionRenderingRegistry {
	static void registerSkyRenderer(ResourceKey<Level> key, SkyRenderer renderer) {
		DimensionRenderingRegistryImpl.registerSkyRenderer(key, renderer);
	}

	static void registerWeatherRenderer(ResourceKey<Level> key, WeatherRenderer renderer) {
		DimensionRenderingRegistryImpl.registerWeatherRenderer(key, renderer);
	}

	static void registerDimensionEffects(ResourceLocation key, DimensionSpecialEffects effects) {
		DimensionRenderingRegistryImpl.registerDimensionEffects(key, effects);
	}

	static void registerCloudRenderer(ResourceKey<Level> key, CloudRenderer renderer) {
		DimensionRenderingRegistryImpl.registerCloudRenderer(key, renderer);
	}

	@Nullable
	static SkyRenderer getSkyRenderer(ResourceKey<Level> key) {
		return DimensionRenderingRegistryImpl.getSkyRenderer(key);
	}

	@Nullable
	static CloudRenderer getCloudRenderer(ResourceKey<Level> key) {
		return DimensionRenderingRegistryImpl.getCloudRenderer(key);
	}

	@Nullable
	static WeatherRenderer getWeatherRenderer(ResourceKey<Level> key) {
		return DimensionRenderingRegistryImpl.getWeatherRenderer(key);
	}

	@Nullable
	static DimensionSpecialEffects getDimensionEffects(ResourceLocation key) {
		return DimensionRenderingRegistryImpl.getDimensionEffects(key);
	}

	@FunctionalInterface
	interface SkyRenderer {
		void render(WorldRenderContext context);
	}

	@FunctionalInterface
	interface WeatherRenderer {
		void render(WorldRenderContext context);
	}

	@FunctionalInterface
	interface CloudRenderer {
		void render(WorldRenderContext context);
	}
}
