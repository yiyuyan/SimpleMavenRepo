package cn.ksmcbrigade.frapi;

import net.neoforged.fml.common.Mod;

@Mod("vkn_ffapi")
public class ModMain {
    public ModMain(){

    }
}
