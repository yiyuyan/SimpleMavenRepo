/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.resource;

import java.util.function.Function;

import org.jetbrains.annotations.ApiStatus;
import net.fabricmc.fabric.impl.resource.loader.ResourceManagerHelperImpl;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;

@ApiStatus.NonExtendable
public interface ResourceManagerHelper {
	@Deprecated
	default void addReloadListener(IdentifiableResourceReloadListener listener) {
		registerReloadListener(listener);
	}

	void registerReloadListener(IdentifiableResourceReloadListener listener);
	void registerReloadListener(ResourceLocation identifier, Function<HolderLookup.Provider, IdentifiableResourceReloadListener> listenerFactory);

	static ResourceManagerHelper get(PackType type) {
		return ResourceManagerHelperImpl.get(type);
	}

	static boolean registerBuiltinResourcePack(ResourceLocation id, ModContainer container, ResourcePackActivationType activationType) {
		return ResourceManagerHelperImpl.registerBuiltinResourcePack(id, "resourcepacks/" + id.getPath(), container, activationType);
	}

	static boolean registerBuiltinResourcePack(ResourceLocation id, ModContainer container, Component displayName, ResourcePackActivationType activationType) {
		return ResourceManagerHelperImpl.registerBuiltinResourcePack(id, "resourcepacks/" + id.getPath(), container, displayName, activationType);
	}

	@Deprecated
	static boolean registerBuiltinResourcePack(ResourceLocation id, ModContainer container, String displayName, ResourcePackActivationType activationType) {
		return ResourceManagerHelperImpl.registerBuiltinResourcePack(id, "resourcepacks/" + id.getPath(), container, Component.literal(displayName), activationType);
	}

	@Deprecated
	static boolean registerBuiltinResourcePack(ResourceLocation id, String subPath, ModContainer container, boolean enabledByDefault) {
		return ResourceManagerHelperImpl.registerBuiltinResourcePack(id, subPath, container,
				enabledByDefault ? ResourcePackActivationType.DEFAULT_ENABLED : ResourcePackActivationType.NORMAL);
	}
}
