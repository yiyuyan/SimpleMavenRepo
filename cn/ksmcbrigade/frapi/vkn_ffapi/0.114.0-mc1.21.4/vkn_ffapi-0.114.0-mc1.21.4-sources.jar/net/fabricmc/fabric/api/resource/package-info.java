@ApiStatus.Internal
package net.fabricmc.fabric.api.resource;

import org.jetbrains.annotations.ApiStatus;
