package net.fabricmc.fabric.mixin.client.rendering.fluid;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerInfo;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerRegistryImpl;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderingImpl;
import net.minecraft.client.renderer.block.LiquidBlockRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Arrays;

@Mixin(LiquidBlockRenderer.class)
public class FluidRendererMixin {
	@Final
	@Shadow
	private TextureAtlasSprite[] lavaSprites;
	@Final
	@Shadow
	private TextureAtlasSprite[] waterSprites;
	@Shadow
	private TextureAtlasSprite waterOverlaySprite;

	@Inject(at = @At("RETURN"), method = "onResourceReload")
	public void onResourceReloadReturn(CallbackInfo info) {
		LiquidBlockRenderer self = (LiquidBlockRenderer) (Object) this;
		((FluidRenderHandlerRegistryImpl) FluidRenderHandlerRegistry.INSTANCE).onFluidRendererReload(self, waterSprites, lavaSprites, waterOverlaySprite);
	}

	@Inject(at = @At("HEAD"), method = "render", cancellable = true)
	public void onHeadRender(BlockAndTintGetter view, BlockPos pos, VertexConsumer vertexConsumer, BlockState blockState, FluidState fluidState, CallbackInfo ci) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();

		if (info.handler == null) {
			FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(fluidState.getType());

			if (handler != null) {
				handler.renderFluid(pos, view, vertexConsumer, blockState, fluidState);
				ci.cancel();
			}
		}
	}

	@ModifyVariable(at = @At(value = "STORE"), method = "render", name = "flag")
	public boolean modLavaCheck(boolean chk) {
		final FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		return info.handler != null ? !info.hasOverlay : chk;
	}

	@ModifyVariable(at = @At(value = "STORE"), method = "render", name = "atextureatlassprite")
	public TextureAtlasSprite[] modSpriteArray(TextureAtlasSprite[] chk) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		if (info.handler != null) {
			TextureAtlasSprite[] sprites = info.sprites;
			if (sprites.length < 3) {
				sprites = Arrays.copyOf(sprites, 3);
			}
			return sprites;
		}
		return chk;
	}

	@ModifyVariable(at = @At(value = "CONSTANT", args = "intValue=16", ordinal = 0, shift = At.Shift.BEFORE), method = "render", name = "i")
	public int modTintColor(int chk, BlockAndTintGetter world, BlockPos pos, VertexConsumer vertexConsumer, BlockState blockState, FluidState fluidState) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		return info.handler != null ? info.handler.getFluidColor(world, pos, fluidState) : chk;
	}

	@Redirect(at = @At(value = "INVOKE",
			target = "Lnet/minecraft/block/BlockState;shouldDisplayFluidOverlay(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/fluid/FluidState;)Z"),
			method = "render")
	public boolean modShouldDisplayFluidOverlay(BlockState state, BlockAndTintGetter world, BlockPos pos, FluidState fluidState) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		if (info.handler != null && info.hasOverlay) {
			return FluidRenderHandlerRegistry.INSTANCE.isBlockTransparent(state.getBlock());
		}
		return state.shouldDisplayFluidOverlay(world, pos, fluidState);
	}

	@ModifyVariable(at = @At(value = "STORE"), method = "render", name = "textureatlassprite2")
	public TextureAtlasSprite modSideSpriteForOverlay(TextureAtlasSprite chk) {
		FluidRenderHandlerInfo info = FluidRenderingImpl.getCurrentInfo();
		if (info.handler != null && info.hasOverlay) {
			return info.overlaySprite;
		}
		return chk;
	}
}