package cn.ksmcbrigade.frapi;

import net.neoforged.fml.common.Mod;

@Mod(ModMain.MOD_ID)
public final class ModMain {
    public static final String MOD_ID = "vkn_ffapi";

    public ModMain() {}
}
